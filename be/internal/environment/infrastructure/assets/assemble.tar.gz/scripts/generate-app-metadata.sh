#!/usr/bin/env bash
#
# generate-app-metadata.sh — 读取妙搭应用的环境变量 / 角色 / 自动化，生成 YAML 描述文件
#
# 产出三个文件（写入 --out-dir）：
#   env.md         用 YAML 描述应用环境变量（开放平台 env_vars 接口，dev + online 合并）
#   roles.md       用 YAML 描述应用角色权限（开放平台 roles 接口）
#   automation.md  用 YAML 描述应用自动化触发器（开放平台 triggers 接口）
#
# 数据来源（通过 lark-cli api 透传开放平台 REST 接口）：
#   env        -> POST /open-apis/spark/v1/apps/{app_id}/env_vars
#   roles      -> GET  /open-apis/spark/v1/apps/{app_id}/roles
#   automation -> GET  /open-apis/spark/v1/apps/{app_id}/triggers
#
# 用法:
#   ./generate-app-metadata.sh --app-id <app_id> --out-dir <目录>
#
# 参数:
#   --app-id <id>     妙搭应用 ID（app_ 开头）
#   --out-dir <dir>   三个 md 文件的输出目录
#   -h, --help        显示帮助
#
# 依赖: lark-cli、node；当前用户身份由智能伙伴运行时注入
#
set -euo pipefail

# 把包装器目录放到 PATH 最前面：拦截 lark-cli 的「binary response detected」响应，
# 还原 saved_path 指向的真实 JSON body 到 stdout（详见 scripts/bin/lark-cli）。
_WRAP_BIN="$(cd "$(dirname "${BASH_SOURCE[0]}")/bin" 2>/dev/null && pwd || true)"
[[ -n "$_WRAP_BIN" ]] && PATH="$_WRAP_BIN:$PATH"

APP_ID=""
OUT_DIR=""

info()  { printf '\033[36m▸ %s\033[0m\n' "$*"; }
ok()    { printf '\033[32m✔ %s\033[0m\n' "$*"; }
warn()  { printf '\033[33m⚠ %s\033[0m\n' "$*"; }
fail()  { printf '\033[31m✗ %s\033[0m\n' "$*" >&2; exit 1; }

usage() { sed -n '3,27p' "${BASH_SOURCE[0]}" | sed 's/^#\{0,1\} \{0,1\}//'; exit 0; }

while [[ $# -gt 0 ]]; do
  case "$1" in
    -h|--help)   usage ;;
    --app-id)    APP_ID="${2:-}"; shift 2 ;;
    --out-dir)   OUT_DIR="${2:-}"; shift 2 ;;
    --*)         fail "未知选项: $1（用 --help 查看用法）" ;;
    *)           fail "多余参数: $1" ;;
  esac
done

[[ -n "$APP_ID" ]]  || fail "缺少 --app-id"
[[ -n "$OUT_DIR" ]] || fail "缺少 --out-dir"
command -v lark-cli >/dev/null 2>&1 || fail "未找到 lark-cli"
command -v node >/dev/null 2>&1     || fail "未找到 node"

mkdir -p "$OUT_DIR"
TMP_DIR="$(mktemp -d "${TMPDIR:-/tmp}/miaoda-metadata.XXXXXX")"
trap 'rm -rf "$TMP_DIR"' EXIT

# json_page_token: 从开放平台响应里取下一页 page_token
json_page_token() {
  node -e '
    let d="";process.stdin.on("data",c=>d+=c).on("end",()=>{
      try{
        const j=JSON.parse(d);const data=j.data||{};
        const page=data.pagination||data.page||{};
        const hasMore=data.has_more ?? page.has_more ?? false;
        const next=data.page_token||data.pageToken||page.page_token||page.pageToken||"";
        process.stdout.write(hasMore?String(next):"");
      }
      catch(_){process.stdout.write("");}
    });
  '
}

# api_items: 从开放平台响应中提取列表字段，兼容不同资源的字段命名
api_items() {
  node -e '
    let d="";process.stdin.on("data",c=>d+=c).on("end",()=>{
      try{
        const data=JSON.parse(d).data||{};
        const items=data.items||data.roles||data.triggers||data.env_vars||data.list||[];
        process.stdout.write(JSON.stringify(Array.isArray(items)?items:[]));
      }catch(_){process.stdout.write("[]");}
    });
  '
}

# api_params: 生成分页参数，避免手工拼接 page_token 造成 JSON 转义问题
api_params() {
  node -e '
    const token=process.argv[2];
    const params={page_size:100};
    if(token) params.page_token=token;
    process.stdout.write(JSON.stringify(params));
  ' "${1:-}"
}

# collect_api_items: 通过 lark-cli api 调开放平台接口并分页聚合列表
# 带超时保护（perl alarm，macOS 无 coreutils timeout）：单次调用挂起时快速失败，
# 不让整体流程长时间空转。
LARK_API_TIMEOUT="${LARK_API_TIMEOUT:-90}"
collect_api_items() {
  # $1=输出文件 $2=HTTP 方法 $3=接口路径 $4=请求体 JSON（GET 传空字符串）
  local out_file="$1" method="$2" path="$3" body_json="${4:-}"
  # 每个调用用独立临时文件（BSD/macOS mktemp 要求随机占位 X 在模板末尾）
  local token="" json items_file rc
  items_file="$(mktemp "$TMP_DIR/items.jsonl.XXXXXX")"
  while :; do
    local params
    params="$(api_params "$token")"
    rc=0
    if [[ "$method" == "POST" ]]; then
      json="$(perl -e 'alarm shift; exec @ARGV' "$LARK_API_TIMEOUT" \
        lark-cli api POST "$path" --params "$params" --data "$body_json" \
        --as user 2>&1)" || rc=$?
    else
      json="$(perl -e 'alarm shift; exec @ARGV' "$LARK_API_TIMEOUT" \
        lark-cli api GET "$path" --params "$params" --as user 2>&1)" || rc=$?
    fi
    if [[ "$rc" -ne 0 ]]; then
      [[ "$rc" -eq 142 ]] && warn "调用超时（>${LARK_API_TIMEOUT}s）: $method $path"
      return 1
    fi
    printf '%s' "$json" | api_items | node -e '
      let d="";process.stdin.on("data",c=>d+=c).on("end",()=>{
        try{for(const it of JSON.parse(d))process.stdout.write(JSON.stringify(it)+"\n");}catch(_){}
      });
    ' >> "$items_file"
    token="$(printf '%s' "$json" | json_page_token)"
    [[ -n "$token" ]] || break
  done
  node -e '
    const fs=require("fs");
    const rows=fs.readFileSync(process.argv[1],"utf8").split(/\n/).filter(Boolean).map(l=>JSON.parse(l));
    fs.writeFileSync(process.argv[2],JSON.stringify(rows));
  ' "$items_file" "$out_file"
}

# ---------------------------------------------------------------------------
# 串行抓取：环境变量(dev/online)、角色、自动化
# ---------------------------------------------------------------------------
# ⚠ 必须串行，不要改回后台并发（`... &` + wait）：
#   实测 lark-cli 对「二进制响应」（本项目中较大的 SELECT/列表响应会命中）
#   使用**固定共享落盘路径** download.txt，且不受 TMPDIR 控制。并发调用会
#   互相覆盖，后完成的请求把 body 覆盖成自己的，先完成的调用读到别人的数据
#   —— 且不报错。曾实测 4 路并发 marker 全变成最后一个请求的值。
#   这会让 env.md / roles.md / automation.md 静默写入错乱内容，
#   比慢几秒危险得多。四个请求都是秒级，串行代价可忽略。
info "串行读取环境变量（dev / online）、角色、自动化"
ENV_DEV_JSON="$TMP_DIR/env-dev.json"
ENV_ONLINE_JSON="$TMP_DIR/env-online.json"
ROLES_JSON="$TMP_DIR/roles.json"
AUTO_JSON="$TMP_DIR/automations.json"

collect_api_items "$ENV_DEV_JSON" POST "/open-apis/spark/v1/apps/$APP_ID/env_vars" \
  '{"env":"dev","scene":2}' \
  || { warn "读取 dev 环境变量失败，按空处理"; echo '[]' > "$ENV_DEV_JSON"; }
collect_api_items "$ENV_ONLINE_JSON" POST "/open-apis/spark/v1/apps/$APP_ID/env_vars" \
  '{"env":"online","scene":2}' \
  || { warn "读取 online 环境变量失败，按空处理"; echo '[]' > "$ENV_ONLINE_JSON"; }
collect_api_items "$ROLES_JSON" GET "/open-apis/spark/v1/apps/$APP_ID/roles" \
  || { warn "读取角色失败，按空处理"; echo '[]' > "$ROLES_JSON"; }
collect_api_items "$AUTO_JSON" GET "/open-apis/spark/v1/apps/$APP_ID/triggers" \
  || { warn "读取应用自动化失败，按空处理"; echo '[]' > "$AUTO_JSON"; }

# 兜底：任一步骤异常未写出文件，按空数组处理
[[ -f "$ENV_DEV_JSON" ]]    || echo '[]' > "$ENV_DEV_JSON"
[[ -f "$ENV_ONLINE_JSON" ]] || echo '[]' > "$ENV_ONLINE_JSON"
[[ -f "$ROLES_JSON" ]]      || echo '[]' > "$ROLES_JSON"
[[ -f "$AUTO_JSON" ]]       || echo '[]' > "$AUTO_JSON"

# ---------------------------------------------------------------------------
# 渲染三个 YAML 文件
# ---------------------------------------------------------------------------
node - "$ENV_DEV_JSON" "$ENV_ONLINE_JSON" "$ROLES_JSON" "$AUTO_JSON" "$OUT_DIR" <<'NODE'
const fs = require('fs');
const [envDevFile, envOnlineFile, rolesFile, autoFile, outDir] = process.argv.slice(2);

// --- YAML 标量安全渲染：需要引号时用 JSON.stringify（合法的 YAML 双引号标量）---
function needsQuote(s) {
  if (s === '') return true;
  if (/^\s|\s$/.test(s)) return true;                       // 首尾空白
  if (/[:#\[\]{}&*!|>'"%@`,]/.test(s)) return true;         // YAML 特殊字符
  if (/[\n\t]/.test(s)) return true;                        // 控制字符
  if (/^(true|false|null|~|yes|no|on|off)$/i.test(s)) return true; // 布尔/空值歧义
  if (/^[-+]?(\d+\.?\d*|\.\d+)([eE][-+]?\d+)?$/.test(s)) return true; // 数字歧义（如 "3000"）
  return false;
}
function y(v) {
  if (v === null || v === undefined) return '""';
  if (typeof v === 'number' || typeof v === 'boolean') return String(v);
  const s = String(v);
  return needsQuote(s) ? JSON.stringify(s) : s;
}
function readItems(file, pickArray) {
  try {
    const j = JSON.parse(fs.readFileSync(file, 'utf8'));
    return pickArray(j) || [];
  } catch (_) { return []; }
}

// ---------------- env.md ----------------
// 导出 key + 真实 value：部署侧据此自动写入目标应用环境变量。
// 历史缺陷：value 曾恒为空串，而部署侧 parse_env_md 会丢弃空值项，
// 导致「导出看似成功、部署静默跳过」，应用上线后所有外部集成失效。
// 因此这里必须导出真实值；env.md 含敏感值，zip 需妥善保管（见 SKILL.md 关键约束）。
// 妙搭平台内置的系统级环境变量，部署时由平台自动注入，导出时过滤掉
const ENV_KEY_BLACKLIST = new Set([
  'INTEGRATION_TOKEN',
  'MIAODA_APP_ARCH_TYPE',
  'MIAODA_APP_ID',
  'MIAODA_APP_TYPE',
  'SUDA_DATABASE_URL',
]);
const envDev = readItems(envDevFile, j => Array.isArray(j) ? j : ((j.data && j.data.items) || []));
const envOnline = readItems(envOnlineFile, j => Array.isArray(j) ? j : ((j.data && j.data.items) || []));
// key -> { envs:Set, values:Map(env -> value) }
const envMap = new Map();
// 取值兼容多种字段命名：不同接口版本可能用 value / env_value / default_value
function pickEnvValue(it) {
  for (const field of ['value', 'env_value', 'default_value', 'val']) {
    const v = it[field];
    if (v !== undefined && v !== null) return String(v);
  }
  return '';
}
function feedEnv(items, envName) {
  for (const it of items) {
    if (!it || !it.key) continue;
    if (ENV_KEY_BLACKLIST.has(it.key)) continue; // 跳过系统内置变量
    if (!envMap.has(it.key)) envMap.set(it.key, { envs: new Set(), values: new Map() });
    const entry = envMap.get(it.key);
    entry.envs.add(envName);
    entry.values.set(envName, pickEnvValue(it));
  }
}
feedEnv(envDev, 'dev');
feedEnv(envOnline, 'online');

// 空值登记：接口未回带值（如平台加密存储的密钥）时无法自动迁移，
// 必须显式标注，避免再次出现「静默丢弃」。
const emptyValueKeys = [];
const envLines = ['# 环境变量', '', '```yaml', 'env_vars:'];
if (envMap.size === 0) {
  envLines.push('  []');
} else {
  let first = true;
  for (const [key, entry] of envMap.entries()) {
    const envs = ['dev', 'online'].filter(e => entry.envs.has(e));
    // dev / online 值不同时按环境分别输出，避免用一个值覆盖两个环境
    const distinct = [...new Set(envs.map(e => entry.values.get(e) ?? ''))];
    const groups = distinct.length > 1
      ? envs.map(e => ({ envs: [e], value: entry.values.get(e) ?? '' }))
      : [{ envs, value: distinct[0] ?? '' }];
    for (const g of groups) {
      if (!first) envLines.push('');
      first = false;
      if (g.value === '') emptyValueKeys.push(`${g.envs.join('/')}:${key}`);
      envLines.push(`  - key: ${y(key)}`);
      envLines.push(`    value: ${y(g.value)}`);
      envLines.push(`    envs: [${g.envs.join(', ')}]`);
    }
  }
}
envLines.push('```', '');
if (emptyValueKeys.length > 0) {
  envLines.push(
    '> 以下变量接口未回带值（可能由平台加密存储），部署时无法自动写入，',
    '> 需在目标应用开发态手动补录：',
    ...emptyValueKeys.map(k => `> - ${k}`),
    '',
  );
}
fs.writeFileSync(`${outDir}/env.md`, envLines.join('\n'));

// ---------------- roles.md ----------------
const roles = readItems(rolesFile, j => Array.isArray(j) ? j : ((j.data && j.data.items) || []));
const roleLines = ['# 应用角色', '', '```yaml', 'roles:'];
if (roles.length === 0) {
  roleLines.push('  []');
} else {
  let first = true;
  for (const r of roles) {
    const roleId = r.role_id || r.id || '';
    if (!roleId) continue;
    if (!first) roleLines.push('');
    first = false;
    roleLines.push(`  - role_id: ${y(roleId)}`);
    roleLines.push(`    name: ${y(r.name || '')}`);
    roleLines.push(`    description: ${y(r.description || '')}`);
    // 妙搭内置系统管理员角色的 role_id 约定为 "admin"，标记 admin: true
    if (String(roleId) === 'admin') roleLines.push('    admin: true');
  }
}
roleLines.push('```', '');
fs.writeFileSync(`${outDir}/roles.md`, roleLines.join('\n'));

// ---------------- automation.md ----------------
const autos = readItems(autoFile, j => Array.isArray(j) ? j : ((j.data && j.data.items) || []));
const autoLines = ['# 自动化', '', '```yaml', 'automations:'];
if (autos.length === 0) {
  autoLines.push('  []');
} else {
  let first = true;
  for (const a of autos) {
    if (!a || !a.name) continue;
    if (!first) autoLines.push('');
    first = false;
    autoLines.push(`  - name: ${y(a.name)}`);
    if (a.description != null && a.description !== '') autoLines.push(`    description: ${y(a.description)}`);
    autoLines.push(`    trigger_type: ${y(a.trigger_type || '')}`);
    // 展开 trigger_condition：cron/timezone、record_change 的 event/table、webhook 等
    const cond = a.trigger_condition || {};
    for (const [k, v] of Object.entries(cond)) {
      if (v === null || v === undefined) continue;
      if (typeof v === 'object') { autoLines.push(`    ${k}: ${y(JSON.stringify(v))}`); }
      else { autoLines.push(`    ${k}: ${y(v)}`); }
    }
    autoLines.push(`    status: ${y(a.status || '')}`);
  }
}
autoLines.push('```', '');
fs.writeFileSync(`${outDir}/automation.md`, autoLines.join('\n'));

console.log(`env_vars=${envMap.size} roles=${roles.length} automations=${autos.length}`);
NODE

STATS="$(node - "$ENV_DEV_JSON" "$ENV_ONLINE_JSON" "$ROLES_JSON" "$AUTO_JSON" <<'NODE'
const fs=require('fs');
const [ed,eo,rf,af]=process.argv.slice(2);
const items=f=>{try{const j=JSON.parse(fs.readFileSync(f,'utf8'));return Array.isArray(j)?j:((j.data&&j.data.items)||[]);}catch(_){return[];}};
const keys=new Set();for(const it of [...items(ed),...items(eo)])if(it&&it.key)keys.add(it.key);
console.log(`${keys.size} ${items(rf).length} ${items(af).length}`);
NODE
)"
read -r N_ENV N_ROLE N_AUTO <<< "$STATS"
ok "已生成 env.md（${N_ENV} 个变量）、roles.md（${N_ROLE} 个角色）、automation.md（${N_AUTO} 个自动化）: $OUT_DIR"

