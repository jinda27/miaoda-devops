const quoteIdent = (value) => `"${String(value).replace(/"/g, '""')}"`;
const normalizeSql = (value) => String(value).replace(/\s+/gu, ' ').trim();
const keyOf = (table, name) => JSON.stringify([table, name]);

// 仅移除源 schema 的标识符前缀，保留字符串字面量。
function unqualifyDefinition(definition, schema) {
  const tokens = definition.match(/[Ee]'(?:\\.|''|[^'])*'|'(?:''|[^'])*'|"(?:[^"]|"")*"|[A-Za-z_][\w$]*|./gsu) || [];
  const result = [];
  for (let i = 0; i < tokens.length; i += 1) {
    // 源 schema 下的对象部署到目标应用的当前 schema。
    if ((tokens[i] === schema || tokens[i] === quoteIdent(schema)) && tokens[i + 1] === '.') {
      i += 1;
      continue;
    }
    result.push(tokens[i]);
  }
  return result.join('').replace(/;?\s*$/u, ';');
}

export class SchemaStructure {
  constructor(rows, tables) {
    this.constraints = new Map();
    this.indexes = new Map();
    this.expected = [];
    this.tableNames = new Set(tables.map((table) => table.name));
    const seen = new Set();
    for (const row of rows) {
      const { object_kind: kind, table_name: table, object_name: name, definition, schema_name: schema } = row;
      // 结构查询不得返回无法归属或定义缺失的对象。
      if (!this.tableNames.has(table) || !name || !definition || !schema || !['constraint', 'index'].includes(kind)) {
        throw new Error(`索引/约束元数据不完整：${table || '?'}.${name || '?'}`);
      }
      const key = keyOf(table, name);
      // 分页重复或源对象重复必须中断，避免数量校验失真。
      if (seen.has(`${kind}:${key}`)) throw new Error(`索引/约束元数据重复：${table}.${name}`);
      seen.add(`${kind}:${key}`);
      const normalized = unqualifyDefinition(definition, schema);
      const object = { ...row, definition: normalized };
      const target = kind === 'constraint' ? this.constraints : this.indexes;
      // 同一张表的索引和约束保持源库顺序。
      if (!target.has(table)) target.set(table, []);
      target.get(table).push(object);
    }
    this.prepareExpectations(tables);
  }

  constraintStatement(row) {
    return `ALTER TABLE ${quoteIdent(row.table_name)} ADD CONSTRAINT ${quoteIdent(row.object_name)} ${row.definition}`;
  }

  indexStatement(row) {
    // 独立索引完整保留 UNIQUE、WHERE、表达式、INCLUDE 等定义。
    if (!/^CREATE\s+(?:UNIQUE\s+)?INDEX\s/iu.test(row.definition) || /"undefined"/iu.test(row.definition)) {
      throw new Error(`索引定义无效：${row.table_name}.${row.object_name}`);
    }
    return row.definition.replace(/^(CREATE\s+(?:UNIQUE\s+)?INDEX)\s+/iu, '$1 IF NOT EXISTS ');
  }

  prepareExpectations(tables) {
    for (const table of tables) {
      const constraints = this.constraints.get(table.name) || [];
      const indexes = this.indexes.get(table.name) || [];
      const byName = new Map(constraints.map((row) => [row.object_name, row]));
      // metadata 标记了主键时，权威系统表必须有对应主键。
      if (table.columns.some((column) => column.is_primary_key) && !constraints.some((row) => row.constraint_type === 'p')) {
        throw new Error(`缺少源库主键定义：${table.name}`);
      }
      for (const row of constraints) {
        // 不支持的约束类型不得静默丢失。
        if (!['p', 'u', 'c', 'f', 'x'].includes(row.constraint_type)) {
          throw new Error(`不支持的约束类型：${table.name}.${row.object_name}`);
        }
        this.expected.push({ kind: 'constraint', table: table.name, name: row.object_name, statement: this.constraintStatement(row) });
      }
      for (const row of indexes) {
        // 仅约束真实拥有的索引由对应约束创建，不按同列关系猜测。
        if (row.constraint_name) {
          const owner = byName.get(row.constraint_name);
          if (!owner || !['p', 'u', 'x'].includes(owner.constraint_type) || owner.index_name !== row.object_name) {
            throw new Error(`索引所属约束不完整：${table.name}.${row.object_name}`);
          }
          continue;
        }
        this.expected.push({ kind: 'index', table: table.name, name: row.object_name, statement: this.indexStatement(row) });
      }
      for (const row of constraints) {
        // 主键、唯一和排除约束必须能对应到真实支撑索引。
        if (['p', 'u', 'x'].includes(row.constraint_type) && !indexes.some((index) =>
          index.object_name === row.index_name && index.constraint_name === row.object_name)) {
          throw new Error(`约束支撑索引缺失：${table.name}.${row.object_name}`);
        }
      }
    }
  }

  tableStatements(table) {
    return this.expected.filter((row) => row.table === table && (
      row.kind === 'index' || this.constraintType(table, row.name) !== 'f'
    )).map((row) => row.statement);
  }

  constraintType(table, name) {
    return (this.constraints.get(table) || []).find((row) => row.object_name === name)?.constraint_type;
  }

  foreignKeyUnits() {
    return this.expected.filter((row) => row.kind === 'constraint' && this.constraintType(row.table, row.name) === 'f')
      .map((row) => ({ name: row.name, text: row.statement, statementCount: 1 }));
  }

  validate(sql) {
    const actual = normalizeSql(sql);
    const errors = [];
    for (const row of this.expected) {
      const statement = normalizeSql(row.statement);
      const first = actual.indexOf(statement);
      // 验证落盘产物中每个对象完整出现一次，遗漏和重复都必须失败。
      if (first < 0 || actual.indexOf(statement, first + statement.length) >= 0) {
        errors.push(`${row.kind === 'index' ? '索引' : '约束'}未完整输出一次：${row.table}.${row.name}`);
      }
    }
    return errors;
  }

  summary() {
    const constraints = [...this.constraints.values()].reduce((count, rows) => count + rows.length, 0);
    const indexes = [...this.indexes.values()].reduce((count, rows) => count + rows.length, 0);
    return { constraints, indexes };
  }
}
