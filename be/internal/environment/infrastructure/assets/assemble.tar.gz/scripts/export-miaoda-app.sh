#!/usr/bin/env bash
#
# export-miaoda-app.sh — 一键导出一个妙搭应用（clone → 生成 docs 产物 → 打包 zip）
#
# 功能:
#   1) 传入妙搭应用标识（app_id/app_key、应用链接或应用名称），解析出确定的 app_id
#      后用 lark-cli clone 该应用到本地
#   2) 保留 clone 应用原有 docs/，仅重建 docs/agent_assemble/ 并生成以下产物：
#        - ddl/*.sql       通过 lark-cli api 查询 metadata 生成的拆分 PostgreSQL DDL
#        - env.md          用 YAML 描述应用环境变量（dev / online）
#        - roles.md        用 YAML 描述应用角色权限
#        - automation.md   用 YAML 描述应用自动化触发器
#   3) 将 clone 应用的 client / docs / server / shared 目录与 package.json 打包为 zip
#
# 用法:
#   ./export-miaoda-app.sh <应用标识> [选项]
#
# 参数:
#   <应用标识>            必填。可为以下任意一种：
#                          - app_id / app_key（app_ 开头，如 app_17beqkepwvf）
#                          - 应用链接（如 https://miaoda.feishu.cn/app/app_17beqkepwvf）
#                          - 应用名称（模糊检索；命中多个时列出候选供选择，退出码 2）
#
# 选项:
#   --out-dir <dir>      zip 输出目录，默认 skill 所在 docs 目录
#   --clone-dir <dir>    clone 目标目录，默认 <out-dir>/.clones/<app_id>
#   --db-environment     DDL 查询源库 metadata 的环境 dev|online；默认省略由服务端自动选分支
#   --keep-clone         保留 clone 目录（默认：打包结束后自动删除托管的 .clones 副本）
#   --no-zip             跳过打包 zip
#   --upload             打包后自动上传 zip 到飞书云盘根目录并输出链接
#   -h, --help           显示帮助
#
# 依赖: lark-cli、git、node、zip；当前用户身份由智能伙伴运行时注入
#
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SKILL_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
DOCS_DIR="$(cd "$SKILL_DIR/.." && pwd)"   # skill 位于 docs/miaoda-app-exporter，其上级即 docs/

# 把包装器目录放到 PATH 最前面：拦截 lark-cli 的「binary response detected」响应，
# 还原 saved_path 指向的真实 JSON body 到 stdout（详见 scripts/bin/lark-cli）。
# 主脚本同样直接调用 apps +get / +list / drive +upload，若不注入就会重现
# 「stdout 只剩元数据 → JSON 解析失败 → 误判调用失败」的历史故障。
#
# 必须校验并修复 wrapper 的执行位：分发链路（打包、复制、下载、解压、权限
# 收敛策略）可能抹掉 exec 位，实测权限变成 -rw------- 时 shell 会跳过 wrapper、
# 静默回退到真实 lark-cli，于是 DDL metadata 查询拿到「binary response detected」
# 而非 JSON，最终表现为 parse fail。静默降级极难排查，故自愈失败即中止。
_WRAP_BIN="$SCRIPT_DIR/bin"
if [[ -d "$_WRAP_BIN" ]]; then
  if [[ -f "$_WRAP_BIN/lark-cli" && ! -x "$_WRAP_BIN/lark-cli" ]]; then
    if chmod +x "$_WRAP_BIN/lark-cli" 2>/dev/null; then
      echo "==> 已修复 lark-cli 包装器执行权限: $_WRAP_BIN/lark-cli" >&2
    else
      echo "!! lark-cli 包装器不可执行且无法自动修复: $_WRAP_BIN/lark-cli" >&2
      echo "!! 继续执行会静默回退到真实 lark-cli，导致 DDL metadata 解析失败。" >&2
      echo "!! 请手动执行: chmod +x '$_WRAP_BIN/lark-cli'" >&2
      exit 1
    fi
  fi
  PATH="$_WRAP_BIN:$PATH"
  # 同一分发链路也会抹掉同目录 .sh 的 exec 位；本脚本会调用它们，一并自愈。
  for _sh in "$SCRIPT_DIR"/*.sh; do
    [[ -f "$_sh" && ! -x "$_sh" ]] && chmod +x "$_sh" 2>/dev/null
  done
  # exec 位只是必要条件：PATH 被外部覆盖或 wrapper 损坏同样会导致回退。
  # 用自检标志实测拦截是否命中，拿不到标志即中止，避免带着失效拦截跑完全程。
  if [[ -f "$_WRAP_BIN/lark-cli" ]]; then
    if [[ "$(lark-cli --wrapper-selftest 2>/dev/null)" != *MIAODA_WRAPPER_OK* ]]; then
      echo "!! lark-cli 包装器未生效（PATH 拦截未命中）。" >&2
      echo "!! 继续执行会拿到「binary response detected」而非 JSON。" >&2
      echo "!! 请检查: ls -l '$_WRAP_BIN/lark-cli' 及 PATH 是否被覆盖。" >&2
      exit 1
    fi
  fi
fi

APP_INPUT=""
APP_ID=""
OUT_DIR="$DOCS_DIR"
CLONE_DIR=""
DB_ENVIRONMENT=""
DO_ZIP=true
KEEP_CLONE=false
DO_UPLOAD=false

info()  { printf '\033[36m▸ %s\033[0m\n' "$*"; }
ok()    { printf '\033[32m✔ %s\033[0m\n' "$*"; }
warn()  { printf '\033[33m⚠ %s\033[0m\n' "$*"; }
fail()  { printf '\033[31m✗ %s\033[0m\n' "$*" >&2; exit 1; }

# --- 步骤计时（移植自 deploy-miaoda.sh 的计时模式）-------------------------
SCRIPT_START_TIME=0
CURRENT_STEP_NAME=""
CURRENT_STEP_START=0

format_duration() {
  local total_seconds="$1"
  local hours=$((total_seconds / 3600))
  local minutes=$(((total_seconds % 3600) / 60))
  local seconds=$((total_seconds % 60))
  if [[ "$hours" -gt 0 ]]; then
    printf '%dh%02dm%02ds' "$hours" "$minutes" "$seconds"
  elif [[ "$minutes" -gt 0 ]]; then
    printf '%dm%02ds' "$minutes" "$seconds"
  else
    printf '%ds' "$seconds"
  fi
}

finish_current_step() {
  local now elapsed
  if [[ -n "$CURRENT_STEP_NAME" && "$CURRENT_STEP_START" -gt 0 ]]; then
    now="$(date +%s)"
    elapsed=$((now - CURRENT_STEP_START))
    printf '\033[2m  耗时: %s (%s)\033[0m\n' "$(format_duration "$elapsed")" "$CURRENT_STEP_NAME"
    CURRENT_STEP_NAME=""
    CURRENT_STEP_START=0
  fi
}

# step: 结束上一步计时并打印其耗时，再开启当前步骤计时
step() {
  finish_current_step
  CURRENT_STEP_NAME="$*"
  CURRENT_STEP_START="$(date +%s)"
  printf '\n\033[1;35m== %s ==\033[0m\n' "$*"
}

print_total_time() {
  local now elapsed
  finish_current_step
  if [[ "$SCRIPT_START_TIME" -gt 0 ]]; then
    now="$(date +%s)"
    elapsed=$((now - SCRIPT_START_TIME))
    ok "总耗时: $(format_duration "$elapsed")"
  fi
}

usage() { sed -n '3,34p' "${BASH_SOURCE[0]}" | sed 's/^#\{0,1\} \{0,1\}//'; exit 0; }

# compact: 把多行/含控制字符的 CLI 原始返回压成单行摘要，便于放进错误提示
compact() { printf '%s' "${1:-}" | tr '\n\r\t' '   ' | sed 's/  */ /g' | cut -c1-300; }

read_json() {
  node -e '
    let d="";process.stdin.on("data",c=>d+=c).on("end",()=>{
      try{let j=JSON.parse(d);for(const k of process.argv[1].split(".").filter(Boolean))j=(j==null?undefined:j[k]);process.stdout.write(j==null?"":String(j));}catch(e){}
    });
  ' "$1"
}

# extract_app_id_from_input: 从「应用链接」或「app_id/app_key」中提取 app_ 前缀标识
# 命中返回该 app_id（打印到 stdout，退出码 0）；无法直接提取返回非 0（需按名称检索）
extract_app_id_from_input() {
  local raw="$1" token=""
  # 链接形态：取路径中形如 app_xxx 的片段（兼容 /app/app_xxx、?app_id=app_xxx 等）
  if [[ "$raw" == http*://* || "$raw" == */* ]]; then
    token="$(printf '%s' "$raw" | grep -oE 'app_[A-Za-z0-9]+' | head -1 || true)"
  # 纯 app_ 标识（app_id 或 app_key）
  elif [[ "$raw" == app_* ]]; then
    token="$(printf '%s' "$raw" | grep -oE '^app_[A-Za-z0-9]+' | head -1 || true)"
  fi
  [[ -n "$token" ]] && { printf '%s' "$token"; return 0; }
  return 1
}

# list_apps_by_keyword: 按名称模糊检索应用，输出 JSON 数组 [{app_id,name,online_url}]
# 分页聚合所有匹配项；用智能伙伴当前用户的可见范围检索。
list_apps_by_keyword() {
  local keyword="$1" token="" page_json items_file
  items_file="$(mktemp "${TMPDIR:-/tmp}/miaoda-app-search.XXXXXX")"
  : > "$items_file"
  while :; do
    if [[ -n "$token" ]]; then
      page_json="$(lark-cli apps +list --keyword "$keyword" --page-size 50 --page-token "$token" --as user 2>/dev/null || true)"
    else
      page_json="$(lark-cli apps +list --keyword "$keyword" --page-size 50 --as user 2>/dev/null || true)"
    fi
    [[ -n "$page_json" ]] || break
    printf '%s' "$page_json" | node -e '
      let d="";process.stdin.on("data",c=>d+=c).on("end",()=>{
        try{const j=JSON.parse(d);const items=(j.data&&j.data.items)||[];
          for(const it of items)process.stdout.write(JSON.stringify({app_id:it.app_id,name:it.name,online_url:it.online_url||""})+"\n");}catch(_){}
      });
    ' >> "$items_file"
    token="$(printf '%s' "$page_json" | node -e '
      let d="";process.stdin.on("data",c=>d+=c).on("end",()=>{try{const j=JSON.parse(d);const dt=j.data||{};process.stdout.write(dt.has_more?String(dt.page_token||""):"");}catch(_){process.stdout.write("");}});
    ')"
    [[ -n "$token" ]] || break
  done
  node -e '
    const fs=require("fs");
    const rows=fs.readFileSync(process.argv[1],"utf8").split(/\n/).filter(Boolean).map(l=>JSON.parse(l));
    process.stdout.write(JSON.stringify(rows));
  ' "$items_file"
  rm -f "$items_file"
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    -h|--help)         usage ;;
    --out-dir)         OUT_DIR="${2:-}"; shift 2 ;;
    --clone-dir)       CLONE_DIR="${2:-}"; shift 2 ;;
    --db-environment)  DB_ENVIRONMENT="${2:-}"; shift 2 ;;
    --keep-clone)      KEEP_CLONE=true; shift ;;
    --no-zip)          DO_ZIP=false; shift ;;
    --upload)          DO_UPLOAD=true; shift ;;
    --*)               fail "未知选项: $1（用 --help 查看用法）" ;;
    *)
      if [[ -z "$APP_INPUT" ]]; then APP_INPUT="$1"; shift;
      else fail "多余参数: $1"; fi ;;
  esac
done

[[ -n "$APP_INPUT" ]] || fail "缺少 <应用标识> 参数（app_id/app_key、应用链接或应用名称）"

# 仅当显式指定 --db-environment 时校验；默认留空由服务端自动选分支
[[ -z "$DB_ENVIRONMENT" || "$DB_ENVIRONMENT" == "dev" || "$DB_ENVIRONMENT" == "online" ]] \
  || fail "无效 --db-environment: ${DB_ENVIRONMENT}（仅支持 dev 或 online）"

CLONE_DIR_MANAGED=false
# CLONE_DIR 默认值依赖解析后的 app_id，延后到 Step 1 解析出 APP_ID 后再赋值。

# ---------------------------------------------------------------------------
# Step 1: 环境校验
# ---------------------------------------------------------------------------
# 记录总开始时间，并在退出时（含中途 fail）打印当前步骤耗时与总耗时。
SCRIPT_START_TIME="$(date +%s)"
trap print_total_time EXIT
step "Step 1/5 校验环境"
command -v lark-cli >/dev/null 2>&1 || fail "未找到 lark-cli"
command -v git >/dev/null 2>&1      || fail "未找到 git"
command -v node >/dev/null 2>&1     || fail "未找到 node"
$DO_ZIP && { command -v zip >/dev/null 2>&1 || fail "未找到 zip（或用 --no-zip 跳过打包）"; }

# --- 解析应用标识 → app_id ----------------------------------------------------
# 支持三种输入：app_id/app_key、应用链接、应用名称。
#   1) app_/链接：直接提取 app_ 前缀标识；
#   2) 名称：用 apps +list --keyword 模糊检索，命中唯一则用之；命中多个则列出
#      「编号 | 应用名 | app_key | 链接」候选表并以退出码 2 退出，由智能体让用户选编号。
if APP_ID="$(extract_app_id_from_input "$APP_INPUT")"; then
  info "已从输入解析出 app_id: $APP_ID"
else
  info "按名称检索应用: $APP_INPUT"
  SEARCH_JSON="$(list_apps_by_keyword "$APP_INPUT")"
  MATCH_COUNT="$(printf '%s' "$SEARCH_JSON" | read_json .length)"
  [[ -n "$MATCH_COUNT" ]] || MATCH_COUNT=0
  if [[ "$MATCH_COUNT" -eq 0 ]]; then
    fail "$(printf '%s' "\
按名称「${APP_INPUT}」未检索到任何应用。请确认：
  1) 名称是否正确（支持模糊匹配，可尝试更短的关键词）；
  2) 该应用是否在智能伙伴当前用户的可见范围内；
  3) 也可直接改用 app_id/app_key 或应用链接作为输入。")"
  elif [[ "$MATCH_COUNT" -eq 1 ]]; then
    APP_ID="$(printf '%s' "$SEARCH_JSON" | node -e 'let d="";process.stdin.on("data",c=>d+=c).on("end",()=>{try{process.stdout.write(JSON.parse(d)[0].app_id||"");}catch(_){}});')"
    APP_MATCH_NAME="$(printf '%s' "$SEARCH_JSON" | node -e 'let d="";process.stdin.on("data",c=>d+=c).on("end",()=>{try{process.stdout.write(JSON.parse(d)[0].name||"");}catch(_){}});')"
    ok "名称唯一命中: ${APP_MATCH_NAME:-未知} ($APP_ID)"
  else
    # 命中多个：列出候选表（编号 | 应用名 | app_key | 链接），退出码 2 交由用户选择。
    warn "名称「${APP_INPUT}」命中 ${MATCH_COUNT} 个应用，请选择其一后重跑（用编号对应的 app_id/链接作为输入）："
    printf '%s' "$SEARCH_JSON" | node -e '
      let d="";process.stdin.on("data",c=>d+=c).on("end",()=>{
        const rows=JSON.parse(d);
        console.log("编号\t应用名\tapp_key\t链接");
        rows.forEach((r,i)=>{console.log(`${i+1}\t${r.name||""}\t${r.app_id||""}\t${r.online_url||""}`);});
      });
    '
    exit 2
  fi
fi

# 解析出 app_id 后再确定默认 clone 目录（托管在 <out-dir>/.clones/<app_id>）
if [[ -z "$CLONE_DIR" ]]; then
  CLONE_DIR="$OUT_DIR/.clones/$APP_ID"
  CLONE_DIR_MANAGED=true   # 使用默认托管目录，打包结束后可安全清理
fi

# --- 校验目标 app_id 是否存在且当前用户可访问 --------------------------------
# 常见失败：app_id 拼写错误 / 不存在，或该应用不在当前用户的可见范围内（无权限）。
# 这里区分这两类原因，给出可读的中文提示，而非直接抛出 lark-cli 原始报错。
info "校验应用是否可访问: $APP_ID"
GET_JSON="$(lark-cli apps +get --app-id "$APP_ID" --as user 2>&1)" || {
  err_summary="$(compact "$GET_JSON")"
  case "$GET_JSON" in
    *[Nn]"ot "[Ff]"ound"*|*NOTFOUND*|*"not_found"*|*"does not exist"*|*"不存在"*)
      fail "$(printf '%s' "\
找不到应用「${APP_ID}」。请检查：
  1) app_id 是否拼写正确（妙搭应用 ID 通常以 app_ 开头，如 app_17beqkepwvf）；
  2) 该应用是否真实存在。
  lark-cli 原始返回：${err_summary}")" ;;
    *[Pp]"ermission"*|*[Ff]"orbidden"*|*[Uu]"nauthorized"*|*403*|*401*|*"access denied"*|*"无权限"*|*"没有权限"*|*"权限不足"*)
      fail "$(printf '%s' "\
智能伙伴当前用户无权访问应用「${APP_ID}」。
  该应用不在你的可见/可管理范围内，请确认：
  1) app_id 是否属于你有权限的应用（不要填写他人或非本租户的应用 ID）；
  2) 是否已在妙搭平台被授予该应用的访问/管理权限。
  lark-cli 原始返回：${err_summary}")" ;;
    *)
      fail "$(printf '%s' "\
无法访问应用「${APP_ID}」（原因未知，可能是 app_id 无效、无权限或网络/服务异常）。
  请核对 app_id 是否正确、智能伙伴当前用户是否对该应用有权限。
  lark-cli 原始返回：${err_summary}")" ;;
  esac
}
APP_NAME="$(printf '%s' "$GET_JSON" | read_json .data.app.name)"
[[ -n "$APP_NAME" ]] || APP_NAME="$(printf '%s' "$GET_JSON" | read_json .data.name)"
ok "目标应用可访问: ${APP_NAME:-未知} ($APP_ID)"
BUNDLE_APP_NAME="${APP_NAME:-$APP_ID}"
# 路径分隔符不能出现在文件名中，替换后保留应用中文名。
BUNDLE_APP_NAME="${BUNDLE_APP_NAME//\//_}"
BUNDLE_FILE_NAME="${BUNDLE_APP_NAME}_$(date '+%Y%m%d-%H%M%S').zip"

# ---------------------------------------------------------------------------
# Step 2: clone 妙搭应用（只拉源码，跳过 npm install）
# ---------------------------------------------------------------------------
step "Step 2/5 clone 妙搭应用（仅源码）"
mkdir -p "$(dirname "$CLONE_DIR")"
if [[ -d "$CLONE_DIR" && -n "$(ls -A "$CLONE_DIR" 2>/dev/null || true)" ]]; then
  warn "clone 目录已存在且非空，将清空后重新 clone: $CLONE_DIR"
  rm -rf "$CLONE_DIR"
fi

# 优先用 git-credential-init + git clone 只拉源码（秒级，无 npm install）
# 回退到 apps +init（会装依赖，慢，但兼容性好）
CLONE_METHOD="git"
GIT_CRED_OUT="$(lark-cli apps +git-credential-init --app-id "$APP_ID" --as user 2>&1)" || {
  warn "git-credential-init 失败，回退到 apps +init"
  CLONE_METHOD="init"
}

if [[ "$CLONE_METHOD" == "git" ]]; then
  REPO_URL="$(printf '%s' "$GIT_CRED_OUT" | read_json .data.repository_url)"
  if [[ -z "$REPO_URL" ]]; then
    warn "未获取到 repository_url，回退到 apps +init"
    CLONE_METHOD="init"
  fi
fi

if [[ "$CLONE_METHOD" == "git" ]]; then
  info "git clone --depth 1（仅源码，跳过 npm install）"
  GIT_RC=0
  GIT_TERMINAL_PROMPT=0 git clone --depth 1 "$REPO_URL" "$CLONE_DIR" 2>&1 || GIT_RC=$?
  if [[ "$GIT_RC" -ne 0 ]]; then
    # git clone 可能因超时被中断但源码已部分 checkout，检查是否有 index.lock
    if [[ -f "$CLONE_DIR/.git/index.lock" ]]; then
      warn "git clone 被中断（可能超时），删除 index.lock 后恢复 checkout"
      rm -f "$CLONE_DIR/.git/index.lock"
      ( cd "$CLONE_DIR" && git checkout HEAD -- . ) 2>&1 || true
    else
      warn "git clone 失败（RC=$GIT_RC），回退到 apps +init"
      rm -rf "$CLONE_DIR"
      CLONE_METHOD="init"
    fi
  fi
fi

if [[ "$CLONE_METHOD" == "init" ]]; then
  mkdir -p "$CLONE_DIR"
  info "lark-cli apps +init --app-id $APP_ID --dir $CLONE_DIR"
  # apps +init 分两阶段：先 git clone 源码，再本地初始化（装依赖 / 跑 miaoda-cli）。
  # 导出打包只需要源码，第二阶段的初始化失败不影响导出，以「源码是否完整」为准判断。
  INIT_RC=0
  INIT_OUT="$(lark-cli apps +init --app-id "$APP_ID" --dir "$CLONE_DIR" --as user 2>&1)" || INIT_RC=$?
fi

# 妙搭应用代码常放在 clone 目录直属，也可能落在子目录，探测 package.json 定位应用根
APP_ROOT="$CLONE_DIR"
if [[ ! -f "$APP_ROOT/package.json" ]]; then
  found="$(find "$CLONE_DIR" -maxdepth 3 -name package.json -not -path '*/node_modules/*' 2>/dev/null | head -1 || true)"
  [[ -n "$found" ]] && APP_ROOT="$(dirname "$found")"
fi

if [[ ! -f "$APP_ROOT/package.json" ]]; then
  err_summary="$(compact "${INIT_OUT:-${GIT_CRED_OUT:-}}")"
  fail "$(printf '%s' "\
clone 应用「${APP_ID}」失败：未获取到源码（$CLONE_DIR 下找不到 package.json）。
  请确认智能伙伴当前用户对该应用有下载/管理权限。
  lark-cli 原始返回：${err_summary}")"
fi

if [[ "${INIT_RC:-0}" -ne 0 ]]; then
  warn "apps +init 初始化阶段返回非零（RC=$INIT_RC），但源码已完整拉取，继续导出"
  hint_detail="$(compact "$INIT_OUT")"
  [[ -n "$hint_detail" ]] && warn "  lark-cli 摘要：${hint_detail}"
fi
ok "已 clone 到: $APP_ROOT${CLONE_METHOD:+ ($CLONE_METHOD)}.${CLONE_METHOD:+}"

# 保留应用原有 docs/，仅清空本工具生成的 agent_assemble/，避免旧产物残留。
BUNDLE_DOCS_DIR="$APP_ROOT/docs/agent_assemble"
[[ -d "$BUNDLE_DOCS_DIR" ]] && rm -rf "$BUNDLE_DOCS_DIR"
mkdir -p "$BUNDLE_DOCS_DIR"

# ---------------------------------------------------------------------------
# Step 3: 生成 docs/agent_assemble 产物
# ---------------------------------------------------------------------------
step "Step 3/5 生成 docs/agent_assemble 产物"

# 3.1 ddl/*.sql —— 通过 lark-cli api 查询数据库 metadata 分阶段生成
DDL_OUT_DIR="$BUNDLE_DOCS_DIR/ddl"
DDL_ARGS=(--app-id "$APP_ID" --output-dir "$DDL_OUT_DIR")
# 仅在用户显式指定环境时传 --environment，否则交服务端自动选分支
[[ -n "$DB_ENVIRONMENT" ]] && DDL_ARGS+=(--environment "$DB_ENVIRONMENT")
bash "$SCRIPT_DIR/generate-schema-ddl.sh" "${DDL_ARGS[@]}" \
  || fail "生成拆分 DDL 失败"
ok "拆分 DDL 已生成: $DDL_OUT_DIR"

# 3.2 env.md / roles.md / automation.md —— 读取应用元数据生成 YAML
bash "$SCRIPT_DIR/generate-app-metadata.sh" \
  --app-id "$APP_ID" \
  --out-dir "$BUNDLE_DOCS_DIR" \
  || fail "生成 env.md / roles.md / automation.md 失败"

# ---------------------------------------------------------------------------
# Step 4: 打包 zip
# ---------------------------------------------------------------------------
step "Step 4/5 打包 zip"
ZIP_OUT=""
if ! $DO_ZIP; then
  warn "按 --no-zip 跳过打包"
else
  mkdir -p "$OUT_DIR"
  ZIP_OUT="$OUT_DIR/$BUNDLE_FILE_NAME"
  rm -f "$ZIP_OUT"

  PACK_ITEMS=()
  # 核心目录与 package.json：缺失则告警
  for item in client docs server shared package.json; do
    if [[ -e "$APP_ROOT/$item" ]]; then
      PACK_ITEMS+=("$item")
    else
      warn "clone 应用缺少条目，打包时跳过: $item"
    fi
  done
  # 根目录配置文件：部署时 nest build / vite build / lint 依赖这些文件（tsconfig*、
  # nest-cli.json、vite/eslint/stylelint/tailwind/postcss 配置、components.json、
  # package-lock.json、.npmrc、.gitignore 等），缺失会导致云端构建失败。这里全量收集
  # APP_ROOT 顶层普通文件（含点文件），避免固定白名单漏掉变体或新增配置。
  # 仅排除：敏感文件（.env*）、构建产物（*.tsbuildinfo/*.zip/*.log/压缩包）、系统垃圾文件。
  while IFS= read -r root_file; do
    base="$(basename "$root_file")"
    # package.json 已在上方核心循环加入，避免重复
    [[ "$base" == "package.json" ]] && continue
    case "$base" in
      .env|.env.*|*.tsbuildinfo|*.zip|*.log|*.tgz|*.tar|*.tar.gz|.DS_Store)
        warn "跳过敏感/产物文件，不打包: $base"; continue ;;
    esac
    PACK_ITEMS+=("$base")
    info "已追加打包根目录文件: $base"
  done < <(find "$APP_ROOT" -maxdepth 1 -type f 2>/dev/null | sort)
  [[ "${#PACK_ITEMS[@]}" -gt 0 ]] || fail "clone 应用中无任何可打包条目（client/docs/server/shared/package.json 均缺失）"

  # 特定模板版本 2.2.4 的 postinstall 依赖 scripts/apply-patch-pnpm.js，需一并打包
  if [[ -f "$APP_ROOT/package.json" ]]; then
    PKG_VERSION="$(read_json .version < "$APP_ROOT/package.json")"
    if [[ "$PKG_VERSION" == "2.2.4" ]]; then
      if [[ -f "$APP_ROOT/scripts/apply-patch-pnpm.js" ]]; then
        PACK_ITEMS+=("scripts/apply-patch-pnpm.js")
        info "检测到 version=2.2.4，已追加打包: scripts/apply-patch-pnpm.js"
      else
        warn "version=2.2.4 但缺少 scripts/apply-patch-pnpm.js，构建阶段 postinstall 可能失败"
      fi
    fi
  fi

  # 防自包含：若输出目录 OUT_DIR 落在被打包的 APP_ROOT 内部（例如把项目根当作
  # clone 目录，而产物又写回其中的 docs/），zip 会把自身产物、skill 脚本乃至
  # 正在写入的 zip 递归打进去。这里把 OUT_DIR 相对 APP_ROOT 的路径加入排除规则。
  ZIP_EXCLUDES=('*/node_modules/*' 'node_modules/*' '*/.git/*' '.git/*')
  APP_ROOT_ABS="$(cd "$APP_ROOT" && pwd)"
  OUT_DIR_ABS="$(cd "$OUT_DIR" && pwd)"
  if [[ "$OUT_DIR_ABS" == "$APP_ROOT_ABS/"* ]]; then
    rel_out="${OUT_DIR_ABS#"$APP_ROOT_ABS"/}"
    warn "输出目录位于应用目录内部（$rel_out），已从打包中排除以避免自包含"
    ZIP_EXCLUDES+=("$rel_out/*" "$rel_out")
  fi

  # 先写到 APP_ROOT 外的临时文件，打包完成再移动到 OUT_DIR，避免把正在写入的
  # zip 本体打进归档。
  TMP_ZIP="$(mktemp "${TMPDIR:-/tmp}/miaoda-bundle.XXXXXX")"
  rm -f "$TMP_ZIP"
  info "zip 打包: ${PACK_ITEMS[*]}"
  ( cd "$APP_ROOT" && zip -r -q "$TMP_ZIP" "${PACK_ITEMS[@]}" -x "${ZIP_EXCLUDES[@]}" ) \
    || fail "zip 打包失败"
  mv -f "$TMP_ZIP" "$ZIP_OUT" || fail "移动 zip 到输出目录失败"
  ok "已打包: $ZIP_OUT"
fi

# ---------------------------------------------------------------------------
# 清理 clone 目录（打包所需的应用副本，产物已随包打入 zip，不必保留）
# ---------------------------------------------------------------------------
CLONE_STATUS="已保留: $APP_ROOT"
if $KEEP_CLONE; then
  info "按 --keep-clone 保留 clone 目录: $CLONE_DIR"
elif ! $CLONE_DIR_MANAGED; then
  warn "clone 目录为 --clone-dir 指定的自定义路径，为安全起见不自动删除: $CLONE_DIR"
else
  # 仅删除本 skill 托管的默认 clone 目录（<out-dir>/.clones 下），且做安全校验，
  # 避免误删 out-dir 或其它路径。
  CLONES_ROOT="$OUT_DIR/.clones"
  CLONES_ROOT_ABS="$(cd "$CLONES_ROOT" 2>/dev/null && pwd || true)"
  CLONE_DIR_ABS="$(cd "$CLONE_DIR" 2>/dev/null && pwd || true)"
  if [[ -n "$CLONE_DIR_ABS" && -n "$CLONES_ROOT_ABS" && "$CLONE_DIR_ABS" == "$CLONES_ROOT_ABS/"* ]]; then
    rm -rf "$CLONE_DIR"
    CLONE_STATUS="已删除: $CLONE_DIR"
    ok "已删除 clone 目录: $CLONE_DIR"
    # 若 .clones 下已无其它应用副本，一并清掉空的 .clones 目录
    if [[ -d "$CLONES_ROOT" ]] && [[ -z "$(ls -A "$CLONES_ROOT" 2>/dev/null || true)" ]]; then
      rmdir "$CLONES_ROOT" 2>/dev/null && info "已清理空目录: $CLONES_ROOT" || true
    fi
  else
    warn "clone 目录不在托管的 .clones 下，跳过自动删除: $CLONE_DIR"
  fi
fi

# ---------------------------------------------------------------------------
# Step 5: 上传 zip 到飞书云盘（--upload）
# ---------------------------------------------------------------------------
UPLOAD_URL=""
if $DO_UPLOAD && [[ -n "$ZIP_OUT" ]]; then
  step "Step 5/5 上传 zip 到飞书云盘"
  UPLOAD_NAME="$BUNDLE_FILE_NAME"
  # lark-cli 要求 --file 为相对当前工作目录的路径，cd 到 zip 所在目录后用文件名
  ZIP_DIR="$(cd "$(dirname "$ZIP_OUT")" && pwd)"
  ZIP_BASE="$(basename "$ZIP_OUT")"
  info "上传: $ZIP_OUT → 飞书云盘根目录（$UPLOAD_NAME）"
  UPLOAD_JSON="$( cd "$ZIP_DIR" && lark-cli drive +upload --file "$ZIP_BASE" --name "$UPLOAD_NAME" --as user 2>&1 )" || {
    err_summary="$(compact "$UPLOAD_JSON")"
    warn "上传失败，zip 仍保留在本地: $ZIP_OUT"
    warn "  lark-cli 摘要: ${err_summary}"
  }
  if [[ -n "$UPLOAD_JSON" ]]; then
    # lark-cli 输出可能含进度行（如 "Uploading: ..."），提取首个 { 开始的 JSON 部分
    UPLOAD_JSON_ONLY="$(printf '%s' "$UPLOAD_JSON" | sed -n '/^{/,$p' | head -20)"
    UPLOAD_URL="$(printf '%s' "$UPLOAD_JSON_ONLY" | read_json .data.url)"
    if [[ -z "$UPLOAD_URL" ]]; then
      UPLOAD_URL="$(printf '%s' "$UPLOAD_JSON_ONLY" | read_json .data.file.url)"
    fi
    if [[ -n "$UPLOAD_URL" ]]; then
      ok "已上传到飞书云盘: $UPLOAD_URL"
    else
      warn "上传返回但未解析到链接，原始返回前 5 行:"
      printf '%s\n' "$UPLOAD_JSON" | head -5
    fi
  fi
fi

# ---------------------------------------------------------------------------
# 结果汇总
# ---------------------------------------------------------------------------
step "导出结果"
echo "  源应用:       ${APP_NAME:-未知} ($APP_ID)"
echo "  clone 目录:   $CLONE_STATUS"
echo "  打包 zip:     ${ZIP_OUT:-未打包}"
if [[ -n "$UPLOAD_URL" ]]; then
  echo "  云盘链接:     $UPLOAD_URL"
fi
echo
echo "  zip 内 docs/agent_assemble/ 产物:"
echo "    - ddl/*.sql       （按类型、表批次、外键拆分的数据库 DDL）"
echo "    - env.md          （环境变量 YAML）"
echo "    - roles.md        （角色权限 YAML）"
echo "    - automation.md   （自动化触发器 YAML）"
ok "导出完成"
