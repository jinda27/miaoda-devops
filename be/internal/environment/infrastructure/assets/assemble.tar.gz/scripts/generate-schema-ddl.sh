#!/usr/bin/env bash
#
# generate-schema-ddl.sh — 通过 lark-cli api 查询妙搭数据库 metadata 生成 PostgreSQL DDL
# MIAODA_DDL_STDIN=1
#
# 数据来源：lark-cli api 透传妙搭开放平台接口（用户身份鉴权，无需注入 token）
#   GET  /open-apis/spark/v1/apps/{app_id}/tables
#   GET  /open-apis/spark/v1/apps/{app_id}/tables/{table}
#   POST /open-apis/spark/v1/apps/{app_id}/sql_commands
#   直接查询真实数据库结构，不解析 schema.ts、也不做任何降级。
#
# 用法:
#   ./generate-schema-ddl.sh --app-id <app_id> --output-dir <ddl目录> [--environment dev|online]
#
# 参数:
#   --app-id <id>     源妙搭应用 app_id
#   --output-dir <dir> 输出拆分 DDL 的目录
#   --environment     查询环境 dev|online；默认省略，由服务端自动选分支
#                     （多环境应用走 dev、未开多环境走 online），规避 dev 未初始化报错
#   -h, --help        显示帮助
#
# 依赖: lark-cli、node；当前用户身份由智能伙伴运行时注入
#
set -euo pipefail

# 把包装器目录放到 PATH 最前面：拦截 lark-cli 的「binary response detected」响应，
# 还原 saved_path 指向的真实 JSON body 到 stdout（详见 scripts/bin/lark-cli）。
_WRAP_BIN="$(cd "$(dirname "${BASH_SOURCE[0]}")/bin" 2>/dev/null && pwd || true)"
[[ -n "$_WRAP_BIN" ]] && PATH="$_WRAP_BIN:$PATH"

APP_ID=""
OUTPUT_DIR=""
ENVIRONMENT=""

info()  { printf '\033[36m▸ %s\033[0m\n' "$*"; }
ok()    { printf '\033[32m✔ %s\033[0m\n' "$*"; }
warn()  { printf '\033[33m⚠ %s\033[0m\n' "$*"; }
fail()  { printf '\033[31m✗ %s\033[0m\n' "$*" >&2; exit 1; }

usage() { sed -n '3,20p' "${BASH_SOURCE[0]}" | sed 's/^#\{0,1\} \{0,1\}//'; exit 0; }

while [[ $# -gt 0 ]]; do
  case "$1" in
    -h|--help)            usage ;;
    --app-id)             APP_ID="${2:-}"; shift 2 ;;
    --output-dir)         OUTPUT_DIR="${2:-}"; shift 2 ;;
    --environment)        ENVIRONMENT="${2:-}"; shift 2 ;;
    --*)                  fail "未知选项: $1（用 --help 查看用法）" ;;
    *)                    fail "多余参数: $1" ;;
  esac
done

[[ -n "$APP_ID" ]] || fail "缺少 --app-id"
[[ -n "$OUTPUT_DIR" ]] || fail "缺少 --output-dir"
# 仅当显式指定时校验环境；默认留空由服务端自动选分支
[[ -z "$ENVIRONMENT" || "$ENVIRONMENT" == "dev" || "$ENVIRONMENT" == "online" ]] \
  || fail "--environment 仅支持 dev 或 online"
command -v lark-cli >/dev/null 2>&1 || fail "未找到 lark-cli"
command -v node >/dev/null 2>&1 || fail "未找到 node"

# ---------------------------------------------------------------------------
# 通过 lark-cli api 拉取 metadata（tables / table / enum）落到临时 JSON
# ---------------------------------------------------------------------------
# lark_api: 调 lark-cli api 透传开放平台接口，成功打印 data JSON，失败返回非零
# 带超时保护：曾出现单次调用挂起导致整体卡 1 小时才失败（临时 token 过期 +
# 二进制响应未被正确还原）。宁可快速失败并给出明确提示，也不要长时间空转。
# macOS 无 coreutils timeout，用 perl alarm 实现，无额外依赖。
LARK_API_TIMEOUT="${LARK_API_TIMEOUT:-90}"
lark_api() {
  local method="$1" path="$2" params="$3" data_json="${4:-}"
  local out rc=0
  # GET 无请求体；POST 通过 stdin 传递 JSON。
  if [[ -n "$data_json" ]]; then
    out="$(printf '%s' "$data_json" | perl -e 'alarm shift; exec @ARGV or die "无法启动 lark-cli: $!"' "$LARK_API_TIMEOUT" \
      lark-cli api "$method" "$path" --params "$params" --data - \
      --as user --format json 2>&1)" || rc=$?
  else
    out="$(perl -e 'alarm shift; exec @ARGV or die "无法启动 lark-cli: $!"' "$LARK_API_TIMEOUT" \
      lark-cli api "$method" "$path" --params "$params" \
      --as user --format json 2>&1)" || rc=$?
  fi
  if [[ "$rc" -ne 0 ]]; then
    # 保留 CLI 的原始错误，便于定位启动和接口失败。
    [[ -z "$out" ]] || printf '%s\n' "$out" >&2
    # 142 = SIGALRM，perl alarm 触发的超时
    if [[ "$rc" -eq 142 ]]; then
      printf 'lark-cli api 调用超时（>%ss）: %s %s\n' \
        "$LARK_API_TIMEOUT" "$method" "$path" >&2
      printf '  可能原因：登录态/临时 token 过期，或响应过大走二进制通道未被还原。\n' >&2
      printf '  处置：确认 lark-cli 登录态后重跑；必要时用 LARK_API_TIMEOUT 调大超时。\n' >&2
    fi
    return 1
  fi
  # 校验 envelope.ok 并输出 data
  printf '%s' "$out" | node -e '
    let s="";process.stdin.setEncoding("utf8").on("data",c=>s+=c).on("end",()=>{
      try{const j=JSON.parse(s);
        if(j.ok===false){process.stderr.write((j.error&&j.error.message)||"api not ok");process.exit(1);}
        process.stdout.write(JSON.stringify(j.data||{}));
      }catch(e){process.stderr.write("parse fail");process.exit(1);}
    });
  ' || return 1
}

# env_param: 用 Node 生成查询参数 JSON，避免手工拼接 JSON 字符串出错。
# 位置参数：$1=env（空则不带，交服务端自动选分支）$2..=key value key value...
env_param() {
  node -e '
    const [env, ...kv] = process.argv.slice(1);
    const p = {};
    if (env) p.env = env;
    for (let i = 0; i + 1 < kv.length; i += 2) {
      const key = kv[i];
      const raw = kv[i + 1];
      // page_size 等数字参数转成 number
      p[key] = /^\d+$/.test(raw) ? Number(raw) : raw;
    }
    process.stdout.write(JSON.stringify(p));
  ' "$ENVIRONMENT" "$@"
}

# sql_check_error: 检测 sql_commands 外层成功、内层失败的响应
sql_check_error() {
  node -e '
    let s="";process.stdin.setEncoding("utf8").on("data",c=>s+=c).on("end",()=>{
      try{
        const j=JSON.parse(s);
        const result=typeof j.result==="string"?JSON.parse(j.result):(j.result||j);
        const arr=Array.isArray(result)?result:[result];
        for(const r of arr){
          if(!r||typeof r!=="object")continue;
          let data=r.data;
          try{if(typeof data==="string")data=JSON.parse(data);}catch(_){}
          if(r.sql_type==="ERROR"||(data&&typeof data==="object"&&!Array.isArray(data)&&data.code)){
            const msg=(data&&data.message)||r.message||String(r.data||"SQL error");
            process.stderr.write(msg+"\n");process.exit(1);
          }
        }
        process.stdout.write(s);
      }catch(e){if(e.message)process.stderr.write(e.message+"\n");process.exit(1);}
    });
  '
}

# lark_sql: 执行单条 SQL，检测 SQL 层错误，输出 data JSON
# 用法: lark_sql <app_path> <sql>
lark_sql() {
  local app_path="$1" sql="$2"
  local payload
  # SQL 序列化时也使用 stdin，避免 Node 进程的参数超长。
  payload="$(printf '%s' "$sql" | node -e 'const fs=require("fs");process.stdout.write(JSON.stringify({sql:fs.readFileSync(0,"utf8")}))')" || return 1
  lark_api POST "$app_path/sql_commands" "$(env_param transactional false)" "$payload" \
    | sql_check_error || return 1
}

# lark_sql_paginated: 分页执行 SELECT 绕过 1000 行限制
# 自动在 SQL 末尾追加 LIMIT/OFFSET，合并所有行为 JSON 数组写入输出文件
# 用法: lark_sql_paginated <app_path> <sql_without_limit> <output_file> [batch_size]
lark_sql_paginated() {
  local app_path="$1" base_sql="$2" out_file="$3"
  local batch_size="${4:-900}" offset=0 pages_file="${out_file}.pages"
  : > "$pages_file" || return 1
  # 逐页写入临时文件，避免把累计结果当作 Node 参数。
  while :; do
    local paged_sql="${base_sql} LIMIT ${batch_size} OFFSET ${offset}"
    local batch
    batch="$(lark_sql "$app_path" "$paged_sql")" || return 1
    # 提取本批行数组
    local rows
    rows="$(printf '%s' "$batch" | node -e '
      let s="";process.stdin.setEncoding("utf8").on("data",c=>s+=c).on("end",()=>{
        const j=JSON.parse(s);
        const result=typeof j.result==="string"?JSON.parse(j.result):(j.result||[]);
        const out=[];
        function collect(value) {
          // sql_commands 可能把 SELECT 行数组多次编码为 JSON 字符串。
          if(typeof value==="string"){collect(JSON.parse(value));return;}
          if(Array.isArray(value)){for(const item of value)collect(item);return;}
          if(!value||typeof value!=="object")return;
          if(value.result!==undefined){collect(value.result);return;}
          if(value.rows!==undefined){collect(value.rows);return;}
          if(value.data!==undefined){collect(value.data);return;}
          if(Object.keys(value).length>0)out.push(value);
        }
        collect(result);
        process.stdout.write(JSON.stringify(out));
      });
    ')" || return 1
    local count
    count="$(printf '%s' "$rows" | node -e 'const fs=require("fs");process.stdout.write(String(JSON.parse(fs.readFileSync(0,"utf8")).length))')" || return 1
    printf '%s\n' "$rows" >> "$pages_file" || return 1
    # 最后一页不足批次大小时结束。
    if [[ "$count" -lt "$batch_size" ]]; then break; fi
    offset=$((offset + batch_size))
  done
  node -e '
    const fs=require("fs");
    const pages=fs.readFileSync(0,"utf8").trimEnd().split("\n");
    process.stdout.write(JSON.stringify(pages.flatMap(page=>JSON.parse(page))));
  ' < "$pages_file" > "$out_file" || return 1
  rm -f "$pages_file"
}

generate_from_api() {
  local source_app_id="$1"
  local output_dir="$2"
  local app_path="/open-apis/spark/v1/apps/$source_app_id"
  local tmp_dir tables_file enum_file ext_file type_file page_token list_json
  local rls_file policy_file post_file structure_file
  tmp_dir="$(mktemp -d "${TMPDIR:-/tmp}/miaoda-ddl.XXXXXX")"
  # 临时目录含库结构信息，退出时务必清理，避免泄漏残留
  trap 'rm -rf "$tmp_dir"' RETURN
  tables_file="$tmp_dir/tables.jsonl"
  enum_file="$tmp_dir/enums.json"
  ext_file="$tmp_dir/extensions.json"
  type_file="$tmp_dir/coltypes.json"
  rls_file="$tmp_dir/rls.json"
  policy_file="$tmp_dir/policies.json"
  post_file="$tmp_dir/post_objects.json"
  structure_file="$tmp_dir/structure.json"
  : > "$tables_file"

  # 1) 查询 enum 的 CREATE TYPE DDL，供建表语句引用
  local enum_sql
  enum_sql="$(printf '%s\n' \
    "SELECT 'CREATE TYPE ' || t.typname || ' AS ENUM ('''" \
    "       || string_agg(e.enumlabel, ''', ''')" \
    "       || ''');' AS create_enum" \
    "FROM pg_type t" \
    "JOIN pg_enum e ON t.oid = e.enumtypid" \
    "GROUP BY t.typname;")"
  lark_sql "$app_path" "$enum_sql" > "$enum_file" || return 1

  # 1b) 查询已安装扩展。vector 等类型依赖扩展先建好，
  #     不导出扩展会让目标库执行 DDL 时报 type "vector" does not exist。
  local ext_sql
  ext_sql="SELECT extname FROM pg_extension WHERE extname <> 'plpgsql' ORDER BY extname;"
  lark_sql "$app_path" "$ext_sql" > "$ext_file" || return 1

  # 索引与约束以系统表定义和真实归属为准，不能用同列关系互相跳过。
  local structure_sql
  structure_sql="$(printf '%s\n' \
    "SELECT 'constraint' AS object_kind, n.nspname AS schema_name," \
    "       t.relname AS table_name, c.conname AS object_name," \
    "       c.contype::text AS constraint_type, pg_get_constraintdef(c.oid) AS definition," \
    "       i.relname AS index_name, NULL::text AS constraint_name" \
    "FROM pg_constraint c JOIN pg_class t ON t.oid = c.conrelid" \
    "JOIN pg_namespace n ON n.oid = t.relnamespace" \
    "LEFT JOIN pg_class i ON i.oid = c.conindid" \
    "WHERE n.nspname = current_schema() AND t.relkind = 'r'" \
    "UNION ALL" \
    "SELECT 'index', n.nspname, t.relname, i.relname," \
    "       NULL::text, pg_get_indexdef(i.oid), i.relname, c.conname" \
    "FROM pg_index x JOIN pg_class t ON t.oid = x.indrelid" \
    "JOIN pg_class i ON i.oid = x.indexrelid" \
    "JOIN pg_namespace n ON n.oid = t.relnamespace" \
    "LEFT JOIN pg_constraint c ON c.conindid = x.indexrelid" \
    "  AND c.conrelid = t.oid AND c.contype IN ('p', 'u', 'x')" \
    "WHERE n.nspname = current_schema() AND t.relkind = 'r'" \
    "ORDER BY table_name, object_kind, object_name")"
  lark_sql_paginated "$app_path" "$structure_sql" "$structure_file" || return 1

  # 1c) 查询列类型的权威字符串。tables metadata 的 data_type 只给裸类型名
  #     （varchar / numeric / vector），丢失长度与精度修饰符，会导致
  #     vector 报 "column does not have dimensions"、varchar 长度约束丢失。
  #     format_type(atttypid, atttypmod) 才是带修饰符的完整类型。
  #     分页查询：sql_commands 有 1000 行结果限制，大应用列数可达上千。
  local type_sql
  type_sql="$(printf '%s\n' \
    "SELECT c.relname AS table_name," \
    "       a.attname  AS column_name," \
    "       format_type(a.atttypid, a.atttypmod) AS full_type" \
    "FROM pg_attribute a" \
    "JOIN pg_class c ON c.oid = a.attrelid" \
    "JOIN pg_namespace n ON n.oid = c.relnamespace" \
    "WHERE n.nspname = current_schema()" \
    "  AND c.relkind = 'r'" \
    "  AND a.attnum > 0" \
    "  AND NOT a.attisdropped" \
    "ORDER BY c.relname, a.attnum")"
  lark_sql_paginated "$app_path" "$type_sql" "$type_file" || return 1

  # 1d) 查询每张表的真实 RLS 开关状态。
  #     历史缺陷：无条件输出 DISABLE ROW LEVEL SECURITY，导致源库启用 RLS 的表
  #     部署后失去行级隔离 —— 这是数据越权风险，不只是功能缺失。
  local rls_sql
  rls_sql="$(printf '%s\n' \
    "SELECT c.relname AS table_name," \
    "       c.relrowsecurity AS rls_enabled," \
    "       c.relforcerowsecurity AS rls_forced" \
    "FROM pg_class c" \
    "JOIN pg_namespace n ON n.oid = c.relnamespace" \
    "WHERE n.nspname = current_schema()" \
    "  AND c.relkind = 'r'" \
    "ORDER BY c.relname;")"
  lark_sql "$app_path" "$rls_sql" > "$rls_file" || return 1

  # 1e) 查询 RLS 策略定义。部署侧 ddl_executor 已完整支持 CREATE POLICY 的
  #     幂等包装与回读校验，此前打包侧却从不产出，能力被浪费。
  local policy_sql
  policy_sql="$(printf '%s\n' \
    "SELECT tablename AS table_name," \
    "       policyname AS policy_name," \
    "       permissive," \
    "       roles::text AS roles," \
    "       cmd," \
    "       qual," \
    "       with_check" \
    "FROM pg_policies" \
    "WHERE schemaname = current_schema()" \
    "ORDER BY tablename, policyname;")"
  lark_sql "$app_path" "$policy_sql" > "$policy_file" || return 1

  # 1f) 查询后置对象：视图、物化视图、独立序列、函数、触发器。
  #     这些对象此前完全不导出，应用一旦用到，部署后必然运行报错。
  #     统一产出到 40_post.sql（部署侧 PHASE_ORDER 已预留 post=40 阶段）。
  #     分页查询：函数定义可能较多且 DDL 文本较长，小批量避免超限。
  local post_sql
  post_sql="$(printf '%s\n' \
    "SELECT 'view' AS obj_kind, c.relname AS obj_name," \
    "       'CREATE OR REPLACE VIEW ' || quote_ident(c.relname) || ' AS ' || pg_get_viewdef(c.oid, true) AS obj_ddl," \
    "       1 AS sort_order" \
    "FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace" \
    "WHERE n.nspname = current_schema() AND c.relkind = 'v'" \
    "UNION ALL" \
    "SELECT 'matview', c.relname," \
    "       'CREATE MATERIALIZED VIEW IF NOT EXISTS ' || quote_ident(c.relname) || ' AS ' || pg_get_viewdef(c.oid, true)," \
    "       2" \
    "FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace" \
    "WHERE n.nspname = current_schema() AND c.relkind = 'm'" \
    "UNION ALL" \
    "SELECT 'sequence', c.relname," \
    "       'CREATE SEQUENCE IF NOT EXISTS ' || quote_ident(c.relname) || ';'," \
    "       0" \
    "FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace" \
    "LEFT JOIN pg_depend d ON d.objid = c.oid AND d.deptype IN ('a','i')" \
    "WHERE n.nspname = current_schema() AND c.relkind = 'S' AND d.objid IS NULL" \
    "UNION ALL" \
    "SELECT 'function', p.proname," \
    "       pg_get_functiondef(p.oid)," \
    "       3" \
    "FROM pg_proc p JOIN pg_namespace n ON n.oid = p.pronamespace" \
    "WHERE n.nspname = current_schema() AND p.prokind IN ('f','p')" \
    "UNION ALL" \
    "SELECT 'trigger', t.tgname," \
    "       pg_get_triggerdef(t.oid) || ';'," \
    "       4" \
    "FROM pg_trigger t" \
    "JOIN pg_class c ON c.oid = t.tgrelid" \
    "JOIN pg_namespace n ON n.oid = c.relnamespace" \
    "WHERE n.nspname = current_schema() AND NOT t.tgisinternal" \
    "ORDER BY sort_order, obj_name")"
  lark_sql_paginated "$app_path" "$post_sql" "$post_file" 200 || {
    echo "后置对象（视图/函数/序列/触发器）查询失败，无法确认源应用是否使用这些对象" >&2
    echo "  打包已中断：继续会产出结构不完整的 DDL，部署后将在运行期报错。" >&2
    echo "  请确认 lark-cli 登录态与应用访问权限后重跑。" >&2
    return 1
  }

  # 2) 分页列出所有表名（先收集全量名单，再并行查询每表结构）
  page_token=""
  local names_file detail_dir total table_params parallel
  names_file="$tmp_dir/table_names.txt"
  detail_dir="$tmp_dir/table_details"
  : > "$names_file"
  mkdir -p "$detail_dir"
  # 分页拉取表名清单
  while :; do
    list_json="$(lark_api GET "$app_path/tables" "$(env_param page_size 100 page_token "$page_token")")" \
      || return 1
    printf '%s' "$list_json" | node -e 'let s="";process.stdin.on("data",c=>s+=c).on("end",()=>{const d=JSON.parse(s);for(const it of (d.items||[]))if(it&&it.name)console.log(it.name)})' >> "$names_file"
    page_token="$(printf '%s' "$list_json" | node -e 'let s="";process.stdin.on("data",c=>s+=c).on("end",()=>{const d=JSON.parse(s);process.stdout.write(d.has_more?String(d.page_token||""):"")})')"
    [[ -n "$page_token" ]] || break
  done
  total="$(wc -l < "$names_file" | tr -d ' ')"
  [[ "$total" -gt 0 ]] || { echo "数据库无任何表" >&2; return 1; }

  # 并行查询每表结构：包装器已按调用隔离落盘，表 detail 为 JSON 响应可安全并发。
  # 用独立 helper + xargs -P 控制并发；每表写独立文件避免并发追加交错。
  table_params="$(env_param)"
  parallel="${DDL_TABLE_PARALLEL:-6}"
  [[ "$parallel" =~ ^[1-9][0-9]*$ ]] \
    || { echo "DDL_TABLE_PARALLEL 必须是正整数: $parallel" >&2; return 1; }
  local fetch_helper="$tmp_dir/fetch_table.sh"
  # 生成单表查询 helper（独立文件，规避 xargs 内联引号嵌套与 export -f 兼容问题）
  cat > "$fetch_helper" <<'HELPER'
#!/usr/bin/env bash
set -uo pipefail
name="$1"; app_path="$2"; params="$3"; dir="$4"; timeout="$5"
# perl alarm 兜底单次调用超时（macOS 无 coreutils timeout）
out="$(perl -e 'alarm shift; exec @ARGV' "$timeout" \
  lark-cli api GET "$app_path/tables/$name" --params "$params" --as user --format json 2>&1)" || exit 1
# 校验 envelope.ok，仅输出 data 对象到以表名命名的独立文件
printf '%s' "$out" | node -e 'let s="";process.stdin.on("data",c=>s+=c).on("end",()=>{try{const j=JSON.parse(s);if(j.ok===false)process.exit(1);process.stdout.write(JSON.stringify(j.data||{}));}catch(e){process.exit(1);}})' > "$dir/$name.json" || exit 1
[[ -s "$dir/$name.json" ]] || exit 1
HELPER
  # xargs 逐表并发调用；任一子进程非零退出即触发 xargs 返回非零。
  # 用 -I% 占位符：table_params 值可能是 {}，若用 -I{} 会被 xargs 误替换成表名。
  if ! xargs -P "$parallel" -I% \
      bash "$fetch_helper" % "$app_path" "$table_params" "$detail_dir" "$LARK_API_TIMEOUT" \
      < "$names_file"; then
    echo "并行查询表结构失败（部分表 detail 未取到）" >&2
    return 1
  fi

  # 按名单原始顺序合并为 JSONL：保持与源库一致的表顺序
  while IFS= read -r name; do
    [[ -n "$name" ]] || continue
    [[ -s "$detail_dir/$name.json" ]] || { echo "缺少表结构: $name" >&2; return 1; }
    cat "$detail_dir/$name.json" >> "$tables_file"
    printf '\n' >> "$tables_file"
  done < "$names_file"

  # 3) 读取 JSONL + CREATE TYPE 结果，渲染 DDL
  node - "$tables_file" "$output_dir" "$enum_file" "$ext_file" "$type_file" "$rls_file" "$policy_file" "$post_file" "$structure_file" "$_WRAP_BIN/../schema-structure.mjs" <<'NODE'
import fs from 'node:fs';
import path from 'node:path';

const tablesFile = process.argv[2];
const outputDir = process.argv[3];
const enumFile = process.argv[4];
const extFile = process.argv[5];
const typeFile = process.argv[6];
const rlsFile = process.argv[7];
const policyFile = process.argv[8];
const postFile = process.argv[9];
const structureFile = process.argv[10];
const { SchemaStructure } = await import((await import('node:url')).pathToFileURL(process.argv[11]).href);

// tables.jsonl：每行一个 table detail 的 data 对象
const records = fs.readFileSync(tablesFile, 'utf8')
  .split(/\n+/u).map((line) => line.trim()).filter(Boolean)
  .map((line) => JSON.parse(line));

// CREATE TYPE：sql_commands 的 result 可能二次编码，递归提取结果行
// keyField 指定该行的判定字段，便于复用到 extension / 列类型等查询
function collectSqlRows(value, rows, keyField = 'create_enum') {
  if (typeof value === 'string') {
    try { collectSqlRows(JSON.parse(value), rows, keyField); } catch (_) {}
    return;
  }
  if (Array.isArray(value)) {
    for (const item of value) collectSqlRows(item, rows, keyField);
    return;
  }
  if (!value || typeof value !== 'object') return;
  // 真实响应把 SELECT 行数组再次编码在 data 字符串中
  if (value.sql_type === 'SELECT' && value.data !== undefined) {
    collectSqlRows(value.data, rows, keyField);
    return;
  }
  if (Array.isArray(value.rows)) { collectSqlRows(value.rows, rows, keyField); return; }
  if (value[keyField] !== undefined) rows.push(value);
}
const enumData = JSON.parse(fs.readFileSync(enumFile, 'utf8'));
const enumRows = [];
collectSqlRows(enumData.result ?? enumData, enumRows, 'create_enum');
const enumStatements = enumRows
  .map((row) => String(row?.create_enum || '').trim())
  .filter((statement) => /^CREATE\s+TYPE\b/iu.test(statement));

// 已安装扩展 -> CREATE EXTENSION 语句（必须在类型和建表之前执行）
const extData = JSON.parse(fs.readFileSync(extFile, 'utf8'));
const extRows = [];
collectSqlRows(extData.result ?? extData, extRows, 'extname');
const extensionStatements = [...new Set(
  extRows.map((row) => String(row?.extname || '').trim()).filter(Boolean),
)].map((name) => `CREATE EXTENSION IF NOT EXISTS "${name.replace(/"/g, '""')}";`);

// 列类型权威表：table -> column -> format_type 完整类型串（含长度/精度/维度）
const typeData = JSON.parse(fs.readFileSync(typeFile, 'utf8'));
const typeRows = [];
collectSqlRows(typeData.result ?? typeData, typeRows, 'full_type');
const authoritativeTypes = new Map();
for (const row of typeRows) {
  const table = String(row?.table_name || '');
  const column = String(row?.column_name || '');
  const fullType = String(row?.full_type || '').trim();
  if (!table || !column || !fullType) continue;
  if (!authoritativeTypes.has(table)) authoritativeTypes.set(table, new Map());
  authoritativeTypes.get(table).set(column, fullType);
}
// 需要修饰符才能正确重建的类型；回退到 metadata 裸类型时要告警
const MODIFIER_SENSITIVE = /^(vector|numeric|decimal|varchar|character varying|char|character|bit|time|timestamp|interval)$/i;
const suspiciousTypeColumns = [];

// RLS 真实开关状态：table -> { enabled, forced }
// 不能无条件 DISABLE —— 源库启用 RLS 的表若被关掉，等于取消行级数据隔离。
function readSqlRows(file, keyField) {
  try {
    const raw = JSON.parse(fs.readFileSync(file, 'utf8'));
    const rows = [];
    collectSqlRows(raw.result ?? raw, rows, keyField);
    return rows;
  } catch (_) { return []; }
}
const structureData = JSON.parse(fs.readFileSync(structureFile, 'utf8'));
const structureRows = [];
collectSqlRows(structureData.result ?? structureData, structureRows, 'object_kind');
const structure = new SchemaStructure(structureRows, records);
function toBool(value) {
  if (typeof value === 'boolean') return value;
  const s = String(value ?? '').trim().toLowerCase();
  return s === 'true' || s === 't' || s === '1' || s === 'yes';
}
const rlsState = new Map();
for (const row of readSqlRows(rlsFile, 'rls_enabled')) {
  const table = String(row?.table_name || '');
  if (!table) continue;
  rlsState.set(table, {
    enabled: toBool(row.rls_enabled),
    forced: toBool(row.rls_forced),
  });
}

// RLS 策略：table -> [CREATE POLICY 语句]
const policiesByTable = new Map();
for (const row of readSqlRows(policyFile, 'policy_name')) {
  const table = String(row?.table_name || '');
  const name = String(row?.policy_name || '');
  if (!table || !name) continue;
  const cmd = String(row?.cmd || 'ALL').toUpperCase();
  const permissive = String(row?.permissive || '').toUpperCase() === 'RESTRICTIVE'
    ? 'RESTRICTIVE' : 'PERMISSIVE';
  // pg_policies.roles 形如 {role1,role2}；{0} / {public} 表示 PUBLIC，无需 TO 子句
  const rolesRaw = String(row?.roles || '').replace(/^\{|\}$/g, '').trim();
  const roles = rolesRaw
    .split(',')
    .map((r) => r.trim().replace(/^"|"$/g, ''))
    .filter((r) => r && r !== '-' && r !== '0' && r.toLowerCase() !== 'public');
  const parts = [
    `CREATE POLICY "${name.replace(/"/g, '""')}" ON "${table.replace(/"/g, '""')}"`,
    `AS ${permissive}`,
    `FOR ${cmd}`,
  ];
  if (roles.length > 0) {
    parts.push(`TO ${roles.map((r) => `"${r.replace(/"/g, '""')}"`).join(', ')}`);
  }
  if (row?.qual) parts.push(`USING (${String(row.qual)})`);
  if (row?.with_check) parts.push(`WITH CHECK (${String(row.with_check)})`);
  if (!policiesByTable.has(table)) policiesByTable.set(table, []);
  policiesByTable.get(table).push(`${parts.join('\n  ')};`);
}

function quoteIdent(name) { return `"${String(name).replace(/"/g, '""')}"`; }
function quoteLiteral(value) { return `'${String(value).replace(/'/g, "''")}'`; }
function normalizeType(column, tableName = '') {
  // 优先用 format_type 返回的权威类型串：它带长度/精度/维度修饰符，
  // 例如 vector(1024)、character varying(255)、numeric(18,2)。
  // metadata 的 data_type 只有裸类型名，直接用会丢修饰符导致目标库建表失败。
  const authoritative = tableName
    ? (authoritativeTypes.get(tableName) || new Map()).get(String(column.name))
    : undefined;
  if (authoritative) {
    // format_type 对数组类型已返回 xxx[]，不要重复追加
    if (column.is_array && !/\[\]$/u.test(authoritative)) return `${authoritative}[]`;
    return authoritative;
  }
  let type = String(column.data_type || 'text').toLowerCase();
  const map = { int8: 'bigint', int4: 'integer', int2: 'smallint', bool: 'boolean', float4: 'real', float8: 'double precision' };
  type = map[type] || type;
  // 回退路径命中修饰符敏感类型时登记告警：这类列极可能因丢失
  // 长度/维度而在目标库执行失败，必须让使用者看到而不是静默降级。
  if (MODIFIER_SENSITIVE.test(type) && tableName) {
    suspiciousTypeColumns.push(`${tableName}.${column.name} -> ${type}`);
  }
  if (column.is_array) type = `${type}[]`;
  return type;
}
function normalizeWhitespace(value) { return String(value || '').replace(/\r/g, '').trim(); }
function analyzeSqlStructure(value) {
  let parenDepth = 0, bracketDepth = 0, inSingleQuote = false;
  for (let i = 0; i < value.length; i += 1) {
    const ch = value[i]; const next = value[i + 1];
    if (ch === "'") { if (inSingleQuote && next === "'") { i += 1; continue; } inSingleQuote = !inSingleQuote; continue; }
    if (inSingleQuote) continue;
    if (ch === '(') parenDepth += 1;
    if (ch === ')') parenDepth -= 1;
    if (ch === '[') bracketDepth += 1;
    if (ch === ']') bracketDepth -= 1;
  }
  return { balancedQuotes: !inSingleQuote, balancedParens: parenDepth === 0, balancedBrackets: bracketDepth === 0 };
}
function isLikelySqlExpression(value) {
  if (!value) return false;
  return (
    /^CURRENT_/i.test(value) || /^(?:LOCALTIME|LOCALTIMESTAMP)\b/i.test(value) || /^now\(\)$/i.test(value) ||
    /^CASE\b/i.test(value) || /^[A-Za-z_][\w$]*(?:\.[A-Za-z_][\w$]*)*\s*\(/.test(value) || /^ARRAY\s*\[/i.test(value) ||
    /^NULL$/i.test(value) || /\bcurrent_setting\s*\(/i.test(value) || /\binterval\b/i.test(value) || /::/.test(value) || /^\(/.test(value)
  );
}
function isIncompleteExpression(value) {
  if (!value) return false;
  const structure = analyzeSqlStructure(value);
  if (!structure.balancedQuotes || !structure.balancedParens || !structure.balancedBrackets) return true;
  const caseCount = (value.match(/\bCASE\b/gi) || []).length;
  const endCount = (value.match(/\bEND\b/gi) || []).length;
  if (caseCount > endCount) return true;
  return false;
}
function compactSqlPreview(value) { return value.replace(/\s+/g, ' ').trim().slice(0, 160); }
function repairTruncatedLiteralDefault(rawValue) {
  if (!rawValue) return rawValue;
  if (/^'/.test(rawValue)) return rawValue;
  const match = rawValue.match(/^([^']*)'(::[A-Za-z_][\w".\[\] ]*)?$/u);
  if (!match) return rawValue;
  const body = match[1];
  const cast = match[2] || '';
  if (body.includes("'")) return rawValue;
  return `'${body}'${cast}`;
}
function renderDefault(column, tableName = '') {
  const rawValue = repairTruncatedLiteralDefault(normalizeWhitespace(column.default_value));
  if (!rawValue) return { sql: '', comment: '' };
  const type = normalizeType(column, tableName);
  if (/\[\]$/i.test(type) && /^\{.*\}$/s.test(rawValue)) return { sql: ` DEFAULT ${quoteLiteral(rawValue)}::${type}`, comment: '' };
  // 空 ARRAY[] 构造无法推断元素类型，按列声明的数组类型补 cast
  if (/\[\]$/i.test(type) && /^ARRAY\s*\[\s*\]$/i.test(rawValue)) return { sql: ` DEFAULT ${rawValue}::${type}`, comment: '' };
  if (/jsonb/i.test(type) && !isLikelySqlExpression(rawValue)) return { sql: ` DEFAULT ${quoteLiteral(rawValue)}::jsonb`, comment: '' };
  if (/json\b/i.test(type) && !isLikelySqlExpression(rawValue)) return { sql: ` DEFAULT ${quoteLiteral(rawValue)}::json`, comment: '' };
  if (isLikelySqlExpression(rawValue)) {
    if (isIncompleteExpression(rawValue)) {
      return { sql: '', comment: `Skipped default for ${quoteIdent(column.name)}: source metadata returned an incomplete SQL expression (${compactSqlPreview(rawValue)}).` };
    }
    if (/^NULL$/i.test(rawValue) && /^(?:varchar|text|char|character varying)/i.test(type)) return { sql: ` DEFAULT ${quoteLiteral(rawValue)}`, comment: '' };
    return { sql: ` DEFAULT ${rawValue}`, comment: '' };
  }
  if (/^(bigint|integer|smallint|numeric|real|double precision|decimal)/i.test(type) && /^-?\d+(\.\d+)?$/.test(rawValue)) return { sql: ` DEFAULT ${rawValue}`, comment: '' };
  if (/^boolean$/i.test(type) && /^(true|false)$/i.test(rawValue)) return { sql: ` DEFAULT ${rawValue.toLowerCase()}`, comment: '' };
  return { sql: ` DEFAULT ${quoteLiteral(rawValue)}`, comment: '' };
}
function columnSql(column, isCompositePrimaryKey, tableName = '') {
  const parts = [quoteIdent(column.name), normalizeType(column, tableName)];
  if (!column.is_allow_null) parts.push('NOT NULL');
  if (column.is_auto_increment) parts.push('GENERATED BY DEFAULT AS IDENTITY');
  const def = renderDefault(column, tableName);
  if (def.sql) parts.push(def.sql.trim());
  return { sql: parts.join(' '), comment: def.comment };
}

const MAX_STATEMENTS = 300;
const MAX_BYTES = 256 * 1024;
const MAX_TABLES = 10;
// 取不到 RLS 状态的表：退出前统一告警，避免静默按 DISABLE 处理
const missingRlsTables = [];

function fileHeader(part) {
  return [
    '-- Generated from source Miaoda database by generate-schema-ddl.sh',
    '-- Source: lark-cli api spark tables / table / sql_commands (metadata).',
    '-- Do not edit manually; regenerate from source app database.',
    `-- Part: ${part}`,
    '',
  ];
}
function renderTableBlock(table) {
  const columns = table.columns || [];
  const primaryKeyCount = columns.filter((column) => column.is_primary_key).length;
  const isCompositePrimaryKey = primaryKeyCount > 1;
  const lines = [`CREATE TABLE IF NOT EXISTS ${quoteIdent(table.name)} (`];
  let statementCount = 2;
  const renderedColumns = columns.map((column) => columnSql(column, isCompositePrimaryKey, table.name));
  lines.push(renderedColumns.map((column) => `  ${column.sql}`).join(',\n'));
  lines.push(');');
  // 按源库真实状态输出 RLS 开关；策略始终导出。
  // 取不到状态时不静默按 DISABLE 处理，否则可能取消源库行级隔离。
  // 此处仅登记，收尾统一中断。
  const rls = rlsState.get(table.name);
  if (rls === undefined) {
    missingRlsTables.push(table.name);
  } else if (rls.enabled) {
    lines.push(`ALTER TABLE ${quoteIdent(table.name)} ENABLE ROW LEVEL SECURITY;`);
    statementCount += 1;
    if (rls.forced) {
      lines.push(`ALTER TABLE ${quoteIdent(table.name)} FORCE ROW LEVEL SECURITY;`);
      statementCount += 1;
    }
  } else {
    lines.push(`ALTER TABLE ${quoteIdent(table.name)} DISABLE ROW LEVEL SECURITY;`);
  }
  // RLS 禁用时策略仍存在，只是不生效，部署包必须完整保留
  for (const policy of policiesByTable.get(table.name) || []) {
    lines.push(policy);
    statementCount += 1;
  }
  for (const column of renderedColumns) if (column.comment) lines.push(`-- ${column.comment}`);
  if (table.description) {
    lines.push(`COMMENT ON TABLE ${quoteIdent(table.name)} IS ${quoteLiteral(table.description)};`);
    statementCount += 1;
  }
  for (const column of columns) {
    if (!column.description) continue;
    lines.push(`COMMENT ON COLUMN ${quoteIdent(table.name)}.${quoteIdent(column.name)} IS ${quoteLiteral(column.description)};`);
    statementCount += 1;
  }
  for (const statement of structure.tableStatements(table.name)) {
    lines.push(statement);
    statementCount += 1;
  }
  lines.push('');
  return { name: table.name, text: lines.join('\n'), statementCount };
}

function renderFile(part, units) {
  return `${[...fileHeader(part), ...units.map((unit) => unit.text)].join('\n')}\n`;
}
function splitUnits(units, part, maxUnits) {
  const batches = [];
  let current = [];
  for (const unit of units) {
    const candidate = [...current, unit];
    const statementCount = candidate.reduce((sum, item) => sum + item.statementCount, 0);
    const byteCount = Buffer.byteLength(renderFile(part, candidate), 'utf8');
    const exceeds = (
      candidate.length > maxUnits
      || statementCount > MAX_STATEMENTS
      || byteCount > MAX_BYTES
    );
    if (current.length > 0 && exceeds) {
      batches.push(current);
      current = [unit];
    } else {
      current = candidate;
    }
    const currentStatements = current.reduce((sum, item) => sum + item.statementCount, 0);
    const currentBytes = Buffer.byteLength(renderFile(part, current), 'utf8');
    if (currentStatements > MAX_STATEMENTS || currentBytes > MAX_BYTES) {
      throw new Error(`DDL block exceeds limits: ${unit.name}`);
    }
  }
  if (current.length > 0) batches.push(current);
  return batches;
}
function writePart(fileName, part, units) {
  fs.writeFileSync(path.join(outputDir, fileName), renderFile(part, units));
}

fs.mkdirSync(outputDir, { recursive: true });
for (const fileName of fs.readdirSync(outputDir)) {
  // 覆盖 10_types.sql 与 20_tables_001.sql 等带序号的分片
  if (/^\d{2}_[a-z0-9_]+[.]sql$/u.test(fileName)) {
    fs.rmSync(path.join(outputDir, fileName));
  }
}

// 扩展必须最先执行：vector 等类型依赖扩展已安装
if (extensionStatements.length > 0) {
  const units = extensionStatements.map((statement, index) => ({
    name: `extension_${index + 1}`,
    text: statement,
    statementCount: 1,
  }));
  fs.writeFileSync(
    path.join(outputDir, '05_extensions.sql'),
    renderFile('extensions', units),
  );
}

if (enumStatements.length > 0) {
  const units = enumStatements.map((statement, index) => ({
    name: `enum_${index + 1}`,
    text: statement,
    statementCount: 1,
  }));
  const content = renderFile('types', units);
  if (units.length > MAX_STATEMENTS || Buffer.byteLength(content, 'utf8') > MAX_BYTES) {
    throw new Error('10_types.sql exceeds limits');
  }
  fs.writeFileSync(path.join(outputDir, '10_types.sql'), content);
}

const tableBatches = splitUnits(
  records.map(renderTableBlock),
  'tables',
  MAX_TABLES,
);
for (const [index, batch] of tableBatches.entries()) {
  writePart(`20_tables_${String(index + 1).padStart(3, '0')}.sql`, 'tables', batch);
}

const foreignKeyUnits = structure.foreignKeyUnits();
const foreignKeyBatches = splitUnits(
  foreignKeyUnits,
  'foreign_keys',
  Number.POSITIVE_INFINITY,
);
for (const [index, batch] of foreignKeyBatches.entries()) {
  writePart(
    `30_foreign_keys_${String(index + 1).padStart(3, '0')}.sql`,
    'foreign_keys',
    batch,
  );
}

// 后置对象（视图 / 物化视图 / 独立序列 / 函数 / 触发器）→ 40_post.sql。
// 必须在所有表和外键之后执行：视图与函数会引用表结构。
// 部署侧 PHASE_ORDER 已预留 post=40，此前该阶段从无产出。
const postRows = readSqlRows(postFile, 'obj_ddl');
const postUnits = [];
for (const row of postRows) {
  const ddl = String(row?.obj_ddl || '').trim();
  if (!ddl) continue;
  const kind = String(row?.obj_kind || 'object');
  const name = String(row?.obj_name || `post_${postUnits.length + 1}`);
  // pg_get_viewdef / pg_get_functiondef 不带结尾分号，需补齐
  const text = `-- ${kind}: ${name}\n${ddl.endsWith(';') ? ddl : `${ddl};`}`;
  postUnits.push({ name: `${kind}_${name}`, text, statementCount: 1 });
}
if (postUnits.length > 0) {
  const postBatches = splitUnits(postUnits, 'post', Number.POSITIVE_INFINITY);
  if (postBatches.length === 1) {
    writePart('40_post.sql', 'post', postBatches[0]);
  } else {
    // 超阈值时分片，文件名仍需匹配部署侧 ^\d{2}_[a-z0-9_]+\.sql$
    for (const [index, batch] of postBatches.entries()) {
      writePart(`40_post_${String(index + 1).padStart(3, '0')}.sql`, 'post', batch);
    }
  }
}

// ===================== 产物完整性校验 =====================
// 打包必须保证产物可直接部署：任何结构信息缺失都在此硬失败，
// 不把「不完整但看起来成功」的 zip 交到部署环节。
// 背景：曾出现列类型查询被误判为空 → 产出「数据库无任何表」的假成功包。
const fatal = [];

// 1) 类型修饰符回退：丢失长度/精度/维度会让目标库列类型与源库不一致
if (suspiciousTypeColumns.length > 0) {
  fatal.push(
    `${suspiciousTypeColumns.length} 列未取到权威类型串（可能丢失长度/精度/维度）：\n`
    + suspiciousTypeColumns.map((item) => `      - ${item}`).join('\n'),
  );
}

// 2) RLS 状态缺失：无法确认是否启用行级隔离，继续会造成数据越权
if (missingRlsTables.length > 0) {
  fatal.push(
    `${missingRlsTables.length} 张表未取到 RLS 真实状态（继续将导致目标库缺失行级隔离）：\n`
    + missingRlsTables.map((item) => `      - ${item}`).join('\n'),
  );
}

// 3) 表数一致性：每张表都必须落到某个 20_tables_*.sql 里
const renderedTableCount = records.length;
if (renderedTableCount === 0) {
  fatal.push('未渲染出任何建表语句（源库表列表为空或查询异常）');
}

// 4) RLS/策略与源库计数一致性：确认导出没有静默丢失。
//    直接回读已落盘的 .sql 文件，校验的是真实产物而非内存中间态。
const rlsEnabledCount = [...rlsState.values()].filter((s) => s.enabled).length;
const policyCount = [...policiesByTable.values()].reduce((n, arr) => n + arr.length, 0);
let writtenEnableRls = 0;
let writtenPolicies = 0;
let writtenCreateTable = 0;
const writtenSql = [];
for (const fileName of fs.readdirSync(outputDir)) {
  if (!/^\d{2}_[a-z0-9_]+[.]sql$/u.test(fileName)) continue;
  const text = fs.readFileSync(path.join(outputDir, fileName), 'utf8');
  writtenSql.push(text);
  writtenEnableRls += (text.match(/ENABLE ROW LEVEL SECURITY/g) || []).length;
  writtenPolicies += (text.match(/CREATE POLICY/g) || []).length;
  writtenCreateTable += (text.match(/CREATE TABLE/g) || []).length;
}
if (writtenCreateTable !== renderedTableCount) {
  fatal.push(
    `建表语句数量不一致：应有 ${renderedTableCount} 张表，产物中 CREATE TABLE ${writtenCreateTable} 条`,
  );
}
if (writtenEnableRls !== rlsEnabledCount) {
  fatal.push(
    `RLS 开关数量不一致：源库启用 ${rlsEnabledCount} 张，产物写出 ${writtenEnableRls} 条 ENABLE`,
  );
}
if (writtenPolicies !== policyCount) {
  fatal.push(
    `RLS 策略数量不一致：源库 ${policyCount} 条，产物写出 ${writtenPolicies} 条`,
  );
}
// 索引与约束按源库对象逐项核对，遗漏即禁止出包。
fatal.push(...structure.validate(writtenSql.join('\n')));

if (fatal.length > 0) {
  process.stderr.write(
    '✗ 产物完整性校验未通过，已中断打包：\n'
    + fatal.map((item, i) => `  ${i + 1}. ${item}`).join('\n') + '\n',
  );
  process.exit(1);
}

// 自检通过后输出摘要，便于人工复核
process.stderr.write(
  `▸ 产物自检通过：表 ${renderedTableCount} 张、启用 RLS ${rlsEnabledCount} 张、`
  + `RLS 策略 ${policyCount} 条、后置对象 ${postUnits.length} 个、`
  + `索引 ${structure.summary().indexes} 个（含约束支撑索引）、约束 ${structure.summary().constraints} 个\n`,
);

// 自检通过后才把表名清单写到 stdout：调用方以此判定成功，
// 不能在自检失败的情况下先交出表名。
for (const table of records) console.log(table.name);
NODE
}

# ---------------------------------------------------------------------------
# 主流程
# ---------------------------------------------------------------------------
mkdir -p "$OUTPUT_DIR"

env_label="${ENVIRONMENT:-auto}"
info "通过 lark-cli api 查询数据库 metadata 生成 DDL: $APP_ID/$env_label"
table_names="$(generate_from_api "$APP_ID" "$OUTPUT_DIR")" \
  || fail "通过 lark-cli api 查询数据库 metadata 失败: $APP_ID/$env_label"
count="$(printf '%s\n' "$table_names" | sed '/^$/d' | wc -l | tr -d ' ')"
file_count="$(find "$OUTPUT_DIR" -maxdepth 1 -type f -name '*.sql' | wc -l | tr -d ' ')"
ok "已生成拆分 DDL（$count 张表 / $file_count 个文件，来源：lark-cli api metadata）: $OUTPUT_DIR"
